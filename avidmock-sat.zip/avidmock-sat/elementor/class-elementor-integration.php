<?php
/**
 * Elementor Integration Class
 * 
 * @package AvidMock_SAT
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AvidMock_SAT_Elementor_Integration {
    
    public function __construct() {
        add_action('elementor/widgets/widgets_registered', array($this, 'register_widgets'));
        add_action('elementor/elements/categories_registered', array($this, 'add_widget_categories'));
        add_action('elementor/frontend/after_enqueue_styles', array($this, 'enqueue_widget_styles'));
        add_action('elementor/frontend/after_register_scripts', array($this, 'enqueue_widget_scripts'));
    }
    
    public function add_widget_categories($elements_manager) {
        $elements_manager->add_category(
            'avidmock-sat',
            array(
                'title' => __('AvidMock SAT', AVIDMOCK_SAT_TEXT_DOMAIN),
                'icon' => 'fa fa-graduation-cap',
            )
        );
    }
    
    public function register_widgets() {
        // Load widget files
        require_once AVIDMOCK_SAT_PLUGIN_PATH . 'elementor/widgets/class-quiz-widget.php';
        require_once AVIDMOCK_SAT_PLUGIN_PATH . 'elementor/widgets/class-quiz-stats-widget.php';
        require_once AVIDMOCK_SAT_PLUGIN_PATH . 'elementor/widgets/class-quiz-results-widget.php';
        
        // Register widgets
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new AvidMock_SAT_Quiz_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new AvidMock_SAT_Quiz_Stats_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new AvidMock_SAT_Quiz_Results_Widget());
    }
    
    public function enqueue_widget_styles() {
        wp_enqueue_style(
            'avidmock-sat-elementor',
            AVIDMOCK_SAT_CSS_URL . 'elementor-widgets.css',
            array(),
            AVIDMOCK_SAT_VERSION
        );
    }
    
    public function enqueue_widget_scripts() {
        wp_register_script(
            'avidmock-sat-elementor',
            AVIDMOCK_SAT_JS_URL . 'elementor-widgets.js',
            array('jquery'),
            AVIDMOCK_SAT_VERSION,
            true
        );
        
        wp_localize_script('avidmock-sat-elementor', 'avidmockSat', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('avidmock_sat_nonce'),
            'strings' => array(
                'selectAnswer' => __('Please select an answer', AVIDMOCK_SAT_TEXT_DOMAIN),
                'timeUp' => __('Time is up!', AVIDMOCK_SAT_TEXT_DOMAIN),
                'error' => __('An error occurred. Please try again.', AVIDMOCK_SAT_TEXT_DOMAIN),
            )
        ));
    }
}
