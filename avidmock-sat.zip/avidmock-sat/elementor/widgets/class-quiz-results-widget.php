<?php
/**
 * AvidMock SAT Quiz Results Widget
 * 
 * @package AvidMock_SAT
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AvidMock_SAT_Quiz_Results_Widget extends \Elementor\Widget_Base {
    
    public function get_name() {
        return 'avidmock-quiz-results';
    }
    
    public function get_title() {
        return __('Quiz Results', AVIDMOCK_SAT_TEXT_DOMAIN);
    }
    
    public function get_icon() {
        return 'eicon-trophy';
    }
    
    public function get_categories() {
        return array('avidmock-sat');
    }
    
    public function get_keywords() {
        return array('results', 'scores', 'achievements', 'certificates', 'completion');
    }
    
    protected function _register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            array(
                'label' => __('Results Settings', AVIDMOCK_SAT_TEXT_DOMAIN),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );
        
        $this->add_control(
            'display_mode',
            array(
                'label' => __('Display Mode', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'latest',
                'options' => array(
                    'latest' => __('Latest Results', AVIDMOCK_SAT_TEXT_DOMAIN),
                    'best' => __('Best Scores', AVIDMOCK_SAT_TEXT_DOMAIN),
                    'history' => __('Complete History', AVIDMOCK_SAT_TEXT_DOMAIN),
                    'certificates' => __('Certificates', AVIDMOCK_SAT_TEXT_DOMAIN),
                ),
            )
        );
        
        $this->add_control(
            'results_count',
            array(
                'label' => __('Number of Results', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 50,
                'step' => 1,
                'default' => 10,
                'condition' => array(
                    'display_mode!' => 'certificates',
                ),
            )
        );
        
        $this->add_control(
            'show_details',
            array(
                'label' => __('Show Detailed Results', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', AVIDMOCK_SAT_TEXT_DOMAIN),
                'label_off' => __('No', AVIDMOCK_SAT_TEXT_DOMAIN),
                'return_value' => 'yes',
                'default' => 'yes',
            )
        );
        
        $this->add_control(
            'show_sharing',
            array(
                'label' => __('Enable Social Sharing', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', AVIDMOCK_SAT_TEXT_DOMAIN),
                'label_off' => __('No', AVIDMOCK_SAT_TEXT_DOMAIN),
                'return_value' => 'yes',
                'default' => 'no',
            )
        );
        
        $this->end_controls_section();
        
        // Style Section
        $this->start_controls_section(
            'style_section',
            array(
                'label' => __('Results Styling', AVIDMOCK_SAT_TEXT_DOMAIN),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            )
        );
        
        $this->add_control(
            'primary_color',
            array(
                'label' => __('Primary Color', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#e4effb',
            )
        );
        
        $this->add_control(
            'success_color',
            array(
                'label' => __('Success Color', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#def7ea',
            )
        );
        
        $this->add_control(
            'warning_color',
            array(
                'label' => __('Warning Color', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#fff3cd',
            )
        );
        
        $this->add_control(
            'accent_color',
            array(
                'label' => __('Accent Color', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#eae8f8',
            )
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        $widget_id = $this->get_id();
        $user_id = get_current_user_id();
        
        ?>
        <div id="avidmock-results-<?php echo esc_attr($widget_id); ?>" class="avidmock-results-container"
             data-widget-id="<?php echo esc_attr($widget_id); ?>"
             data-display-mode="<?php echo esc_attr($settings['display_mode']); ?>"
             data-results-count="<?php echo esc_attr($settings['results_count']); ?>"
             data-user-id="<?php echo esc_attr($user_id); ?>">
            
            <div class="results-header" style="background-color: <?php echo esc_attr($settings['primary_color']); ?>;">
                <h3 class="results-title">
                    <?php 
                    switch($settings['display_mode']) {
                        case 'latest':
                            echo __('Recent Quiz Results', AVIDMOCK_SAT_TEXT_DOMAIN);
                            break;
                        case 'best':
                            echo __('Your Best Scores', AVIDMOCK_SAT_TEXT_DOMAIN);
                            break;
                        case 'history':
                            echo __('Complete Quiz History', AVIDMOCK_SAT_TEXT_DOMAIN);
                            break;
                        case 'certificates':
                            echo __('Your Achievements', AVIDMOCK_SAT_TEXT_DOMAIN);
                            break;
                    }
                    ?>
                </h3>
                <div class="results-filter">
                    <select id="filter-category-<?php echo esc_attr($widget_id); ?>">
                        <option value="">All Categories</option>
                        <option value="algebra">Algebra</option>
                        <option value="geometry">Geometry</option>
                        <option value="calculus">Calculus</option>
                    </select>
                </div>
            </div>
            
            <div class="results-content">
                <?php if ($settings['display_mode'] === 'certificates'): ?>
                    <div class="certificates-grid" id="certificates-<?php echo esc_attr($widget_id); ?>">
                        <div class="certificate-card" style="background-color: <?php echo esc_attr($settings['success_color']); ?>;">
                            <div class="certificate-icon">🏆</div>
                            <h4>SAT Math Mastery</h4>
                            <p>Completed 50+ algebra questions with 90%+ accuracy</p>
                            <div class="certificate-date">Earned: March 15, 2024</div>
                            <button class="certificate-download" style="background-color: <?php echo esc_attr($settings['accent_color']); ?>;">
                                Download Certificate
                            </button>
                        </div>
                        
                        <div class="certificate-card" style="background-color: <?php echo esc_attr($settings['warning_color']); ?>;">
                            <div class="certificate-icon">🥉</div>
                            <h4>Geometry Expert</h4>
                            <p>Achieved 85%+ on 3 consecutive geometry quizzes</p>
                            <div class="certificate-date">Earned: March 10, 2024</div>
                            <button class="certificate-download" style="background-color: <?php echo esc_attr($settings['accent_color']); ?>;">
                                Download Certificate
                            </button>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="results-list" id="results-list-<?php echo esc_attr($widget_id); ?>">
                        <!-- Sample Results -->
                        <div class="result-item" style="border-left: 4px solid <?php echo esc_attr($settings['success_color']); ?>;">
                            <div class="result-main">
                                <div class="result-info">
                                    <h4 class="result-title">Algebra Practice Quiz #15</h4>
                                    <div class="result-meta">
                                        <span class="result-date">March 20, 2024</span>
                                        <span class="result-category">Algebra</span>
                                    </div>
                                </div>
                                <div class="result-score">
                                    <div class="score-circle" style="background-color: <?php echo esc_attr($settings['success_color']); ?>;">
                                        <span class="score-value">92%</span>
                                    </div>
                                </div>
                            </div>
                            
                            <?php if ($settings['show_details'] === 'yes'): ?>
                            <div class="result-details">
                                <div class="detail-stats">
                                    <div class="stat">
                                        <span class="stat-label">Questions:</span>
                                        <span class="stat-value">23/25</span>
                                    </div>
                                    <div class="stat">
                                        <span class="stat-label">Time:</span>
                                        <span class="stat-value">18:32</span>
                                    </div>
                                    <div class="stat">
                                        <span class="stat-label">Accuracy:</span>
                                        <span class="stat-value">92%</span>
                                    </div>
                                </div>
                                
                                <?php if ($settings['show_sharing'] === 'yes'): ?>
                                <div class="result-actions">
                                    <button class="share-btn" style="background-color: <?php echo esc_attr($settings['accent_color']); ?>;">
                                        📤 Share Result
                                    </button>
                                    <button class="review-btn" style="background-color: <?php echo esc_attr($settings['primary_color']); ?>;">
                                        👁️ Review Answers
                                    </button>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="result-item" style="border-left: 4px solid <?php echo esc_attr($settings['warning_color']); ?>;">
                            <div class="result-main">
                                <div class="result-info">
                                    <h4 class="result-title">Geometry Practice Quiz #8</h4>
                                    <div class="result-meta">
                                        <span class="result-date">March 18, 2024</span>
                                        <span class="result-category">Geometry</span>
                                    </div>
                                </div>
                                <div class="result-score">
                                    <div class="score-circle" style="background-color: <?php echo esc_attr($settings['warning_color']); ?>;">
                                        <span class="score-value">78%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="results-footer">
                <button class="load-more-btn" style="background-color: <?php echo esc_attr($settings['primary_color']); ?>;">
                    Load More Results
                </button>
            </div>
        </div>
        
        <style>
        #avidmock-results-<?php echo esc_attr($widget_id); ?> {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            margin: 20px 0;
            overflow: hidden;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .results-header {
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #e9ecef;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .results-title {
            margin: 0;
            font-size: 20px;
            font-weight: 600;
            color: #2c3e50;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .results-filter select {
            padding: 8px 16px;
            border: 1px solid #000;
            border-radius: 20px;
            background: white;
            font-size: 14px;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .results-content {
            padding: 30px;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .result-item {
            background: white;
            border: 1px solid #e9ecef;
            border-radius: 12px;
            margin-bottom: 20px;
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .result-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .result-main {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .result-title {
            margin: 0 0 8px 0;
            font-size: 16px;
            font-weight: 600;
            color: #2c3e50;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .result-meta {
            display: flex;
            gap: 15px;
            font-size: 14px;
            color: #7f8c8d;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .score-circle {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            border: 1px solid #000;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 14px;
            color: #2c3e50;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .certificates-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .certificate-card {
            padding: 30px;
            border-radius: 12px;
            border: 1px solid #000;
            text-align: center;
            transition: transform 0.3s ease;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .certificate-card:hover {
            transform: translateY(-5px);
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .certificate-icon {
            font-size: 48px;
            margin-bottom: 15px;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .certificate-card h4 {
            margin: 0 0 10px 0;
            font-size: 18px;
            font-weight: 600;
            color: #2c3e50;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .certificate-card p {
            margin: 0 0 15px 0;
            color: #7f8c8d;
            font-size: 14px;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .certificate-date {
            font-size: 12px;
            color: #95a5a6;
            margin-bottom: 20px;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .certificate-download {
            padding: 12px 24px;
            border: 1px solid #000;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .certificate-download:hover {
            transform: translateY(-2px);
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .result-details {
            background: #f8f9fa;
            padding: 20px;
            border-top: 1px solid #e9ecef;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .detail-stats {
            display: flex;
            gap: 30px;
            margin-bottom: 15px;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .stat {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .stat-label {
            font-size: 12px;
            color: #7f8c8d;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .stat-value {
            font-size: 16px;
            font-weight: 600;
            color: #2c3e50;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .result-actions {
            display: flex;
            gap: 10px;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .share-btn,
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .review-btn {
            padding: 8px 16px;
            border: 1px solid #000;
            border-radius: 20px;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .results-footer {
            padding: 20px 30px;
            text-align: center;
            border-top: 1px solid #e9ecef;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .load-more-btn {
            padding: 12px 32px;
            border: 1px solid #000;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        #avidmock-results-<?php echo esc_attr($widget_id); ?> .load-more-btn:hover {
            transform: translateY(-2px);
        }
        
        @media (max-width: 768px) {
            #avidmock-results-<?php echo esc_attr($widget_id); ?> .results-header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            #avidmock-results-<?php echo esc_attr($widget_id); ?> .result-main {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            #avidmock-results-<?php echo esc_attr($widget_id); ?> .detail-stats {
                flex-direction: column;
                gap: 15px;
            }
            
            #avidmock-results-<?php echo esc_attr($widget_id); ?> .certificates-grid {
                grid-template-columns: 1fr;
            }
        }
        </style>
        <?php
    }
}
  