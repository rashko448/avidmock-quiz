<?php
/**
 * AvidMock SAT Quiz Widget
 * 
 * @package AvidMock_SAT
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AvidMock_SAT_Quiz_Widget extends \Elementor\Widget_Base {
    
    public function get_name() {
        return 'avidmock-quiz';
    }
    
    public function get_title() {
        return __('AvidMock Quiz', AVIDMOCK_SAT_TEXT_DOMAIN);
    }
    
    public function get_icon() {
        return 'eicon-form-horizontal';
    }
    
    public function get_categories() {
        return array('avidmock-sat');
    }
    
    public function get_keywords() {
        return array('quiz', 'sat', 'math', 'test', 'education');
    }
    
    protected function _register_controls() {
        // Content Tab
        $this->start_controls_section(
            'content_section',
            array(
                'label' => __('Quiz Settings', AVIDMOCK_SAT_TEXT_DOMAIN),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );
        
        $this->add_control(
            'quiz_category',
            array(
                'label' => __('Quiz Category', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '',
                'options' => $this->get_quiz_categories(),
            )
        );
        
        $this->add_control(
            'question_count',
            array(
                'label' => __('Number of Questions', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 50,
                'step' => 1,
                'default' => 10,
            )
        );
        
        $this->add_control(
            'time_per_question',
            array(
                'label' => __('Time per Question (seconds)', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 30,
                'max' => 300,
                'step' => 10,
                'default' => 90,
            )
        );
        
        $this->add_control(
            'show_timer',
            array(
                'label' => __('Show Timer', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', AVIDMOCK_SAT_TEXT_DOMAIN),
                'label_off' => __('Hide', AVIDMOCK_SAT_TEXT_DOMAIN),
                'return_value' => 'yes',
                'default' => 'yes',
            )
        );
        
        $this->add_control(
            'show_hint',
            array(
                'label' => __('Enable Hints', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', AVIDMOCK_SAT_TEXT_DOMAIN),
                'label_off' => __('No', AVIDMOCK_SAT_TEXT_DOMAIN),
                'return_value' => 'yes',
                'default' => 'yes',
            )
        );
        
        $this->end_controls_section();
        
        // Style Tab
        $this->start_controls_section(
            'style_section',
            array(
                'label' => __('Quiz Styling', AVIDMOCK_SAT_TEXT_DOMAIN),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            )
        );
        
        $this->add_control(
            'primary_color',
            array(
                'label' => __('Primary Color', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#e4effb',
            )
        );
        
        $this->add_control(
            'correct_color',
            array(
                'label' => __('Correct Answer Color', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#def7ea',
            )
        );
        
        $this->add_control(
            'incorrect_color',
            array(
                'label' => __('Incorrect Answer Color', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#f8d7da',
            )
        );
        
        $this->add_control(
            'accent_color',
            array(
                'label' => __('Accent Color', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#eae8f8',
            )
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        $widget_id = $this->get_id();
        
        ?>
        <div id="avidmock-quiz-<?php echo esc_attr($widget_id); ?>" class="avidmock-quiz-container" 
             data-widget-id="<?php echo esc_attr($widget_id); ?>"
             data-category="<?php echo esc_attr($settings['quiz_category']); ?>"
             data-question-count="<?php echo esc_attr($settings['question_count']); ?>"
             data-time-limit="<?php echo esc_attr($settings['time_per_question']); ?>"
             data-show-timer="<?php echo esc_attr($settings['show_timer']); ?>"
             data-show-hint="<?php echo esc_attr($settings['show_hint']); ?>">
            
            <!-- Quiz Header -->
            <div class="quiz-header" style="background-color: <?php echo esc_attr($settings['primary_color']); ?>;">
                <div class="quiz-progress">
                    <span class="question-info">
                        Question <span id="current-question-<?php echo esc_attr($widget_id); ?>">1</span> 
                        of <span id="total-questions-<?php echo esc_attr($widget_id); ?>"><?php echo esc_html($settings['question_count']); ?></span>
                    </span>
                    <?php if ($settings['show_timer'] === 'yes'): ?>
                    <div class="timer" id="timer-<?php echo esc_attr($widget_id); ?>">
                        <span>⏱</span>
                        <span id="timer-display-<?php echo esc_attr($widget_id); ?>">01:30</span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Quiz Content -->
            <div class="quiz-content">
                <!-- Question Section -->
                <div class="question-section">
                    <!-- Loading State -->
                    <div class="quiz-loading" id="quiz-loading-<?php echo esc_attr($widget_id); ?>">
                        <div class="loading-spinner"></div>
                        <p>Loading quiz...</p>
                    </div>
                    
                    <!-- Question Content -->
                    <div class="question-content" id="question-content-<?php echo esc_attr($widget_id); ?>" style="display: none;">
                        <div class="question-text" id="question-text-<?php echo esc_attr($widget_id); ?>">
                            <!-- Question will be loaded here -->
                        </div>
                        
                        <!-- Answer Choices -->
                        <div class="answer-choices" id="answer-choices-<?php echo esc_attr($widget_id); ?>">
                            <div class="choice" data-choice="A">
                                <span class="choice-letter">A)</span>
                                <span class="choice-text"></span>
                            </div>
                            <div class="choice" data-choice="B">
                                <span class="choice-letter">B)</span>
                                <span class="choice-text"></span>
                            </div>
                            <div class="choice" data-choice="C">
                                <span class="choice-letter">C)</span>
                                <span class="choice-text"></span>
                            </div>
                            <div class="choice" data-choice="D">
                                <span class="choice-letter">D)</span>
                                <span class="choice-text"></span>
                            </div>
                        </div>
                        
                        <!-- Open Ended Answer -->
                        <div class="open-answer-container" id="open-answer-<?php echo esc_attr($widget_id); ?>" style="display: none;">
                            <textarea id="open-answer-text-<?php echo esc_attr($widget_id); ?>" placeholder="Type your answer here..."></textarea>
                        </div>
                    </div>
                </div>

                <!-- Explanation Section -->
                <div class="explanation-section" id="explanation-section-<?php echo esc_attr($widget_id); ?>" style="display: none;">
                    <div class="explanation-header">
                        <h3>Explanation</h3>
                    </div>
                    <div class="explanation-content" id="explanation-content-<?php echo esc_attr($widget_id); ?>">
                        <!-- Explanation will be loaded here -->
                    </div>
                </div>
            </div>

            <!-- Quiz Controls -->
            <div class="quiz-controls">
                <?php if ($settings['show_hint'] === 'yes'): ?>
                <button class="hint-btn" id="hint-btn-<?php echo esc_attr($widget_id); ?>" style="background-color: <?php echo esc_attr($settings['accent_color']); ?>;">
                    <span>💡</span>
                    Hint
                </button>
                <?php endif; ?>
                
                <div class="action-buttons">
                    <button class="btn btn-submit" id="submit-btn-<?php echo esc_attr($widget_id); ?>" style="background-color: <?php echo esc_attr($settings['primary_color']); ?>;" disabled>
                        Submit
                    </button>
                    <button class="btn btn-next" id="next-btn-<?php echo esc_attr($widget_id); ?>" style="background-color: <?php echo esc_attr($settings['correct_color']); ?>; display: none;">
                        Next
                    </button>
                </div>
            </div>

            <!-- Hint Display -->
            <?php if ($settings['show_hint'] === 'yes'): ?>
            <div class="hint-display" id="hint-display-<?php echo esc_attr($widget_id); ?>" style="background-color: <?php echo esc_attr($settings['accent_color']); ?>; display: none;">
                <strong>Hint:</strong>
                <span id="hint-text-<?php echo esc_attr($widget_id); ?>"></span>
            </div>
            <?php endif; ?>

            <!-- Results Modal -->
            <div class="results-modal" id="results-modal-<?php echo esc_attr($widget_id); ?>" style="display: none;">
                <div class="results-content">
                    <div class="results-title">🎉 Quiz Complete!</div>
                    <div class="results-stats" style="background-color: <?php echo esc_attr($settings['primary_color']); ?>;">
                        <div class="stat">
                            <span class="stat-value" id="final-score-<?php echo esc_attr($widget_id); ?>">0%</span>
                            <span class="stat-label">Score</span>
                        </div>
                        <div class="stat">
                            <span class="stat-value" id="final-correct-<?php echo esc_attr($widget_id); ?>">0/0</span>
                            <span class="stat-label">Correct</span>
                        </div>
                        <div class="stat">
                            <span class="stat-value" id="final-time-<?php echo esc_attr($widget_id); ?>">00:00</span>
                            <span class="stat-label">Time</span>
                        </div>
                    </div>
                    <div class="results-actions">
                        <button class="btn btn-restart" id="restart-btn-<?php echo esc_attr($widget_id); ?>" style="background-color: <?php echo esc_attr($settings['correct_color']); ?>;">
                            Take Again
                        </button>
                        <button class="btn btn-close" id="close-btn-<?php echo esc_attr($widget_id); ?>" style="background-color: <?php echo esc_attr($settings['accent_color']); ?>;">
                            Close
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <style>
        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            overflow: hidden;
            margin: 20px 0;
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .quiz-header {
            color: #2c3e50;
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #e9ecef;
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .question-info {
            font-weight: 600;
            font-size: 16px;
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .timer {
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
            font-size: 16px;
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .quiz-content {
            display: flex;
            min-height: 500px;
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .question-section {
            flex: 1;
            padding: 30px;
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .explanation-section {
            flex: 1;
            background: #f8f9fa;
            border-left: 1px solid #e9ecef;
            padding: 30px;
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .question-text {
            font-size: 16px;
            line-height: 1.6;
            margin-bottom: 25px;
            color: #2c3e50;
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .answer-choices {
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin-bottom: 30px;
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .choice {
            display: flex;
            align-items: center;
            padding: 16px 20px;
            border: 1px solid #000;
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            background: white;
            font-size: 16px;
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .choice:hover {
            background: #f8f9fa;
            transform: translateY(-1px);
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .choice.selected {
            background: <?php echo esc_attr($settings['primary_color']); ?>;
            border-width: 2px;
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .choice.correct {
            background: <?php echo esc_attr($settings['correct_color']); ?>;
            border-width: 2px;
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .choice.incorrect {
            background: <?php echo esc_attr($settings['incorrect_color']); ?>;
            border-width: 2px;
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .choice-letter {
            font-weight: bold;
            margin-right: 15px;
            min-width: 25px;
            color: #2c3e50;
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .choice-text {
            flex: 1;
            color: #2c3e50;
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .quiz-controls {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 30px;
            margin-bottom: 20px;
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .btn {
            padding: 14px 28px;
            border: 1px solid #000;
            border-radius: 20px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            color: #2c3e50;
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .hint-btn {
            background: white;
            color: #2c3e50;
            border: 1px solid #000;
            border-radius: 20px;
            padding: 12px 24px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .hint-display {
            margin: 0 30px 20px 30px;
            padding: 20px;
            border: 1px solid #000;
            border-radius: 20px;
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .results-modal {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .results-content {
            background: white;
            padding: 40px;
            border-radius: 20px;
            border: 1px solid #000;
            text-align: center;
            max-width: 450px;
            width: 90%;
        }

        #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .loading-spinner {
            width: 40px;
            height: 40px;
            border: 4px solid #e1e5e9;
            border-top: 4px solid <?php echo esc_attr($settings['primary_color']); ?>;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 16px auto;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @media (max-width: 768px) {
            #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .quiz-content {
                flex-direction: column;
            }
            
            #avidmock-quiz-<?php echo esc_attr($widget_id); ?> .explanation-section {
                border-left: none;
                border-top: 1px solid #e9ecef;
            }
        }
        </style>
        <?php
    }
    
    private function get_quiz_categories() {
        global $wpdb;
        $table = $wpdb->prefix . 'avidmock_quiz_categories';
        
        $categories = $wpdb->get_results("SELECT id, name FROM $table WHERE is_active = 1 ORDER BY name ASC");
        $options = array('' => 'All Categories');
        
        if ($categories) {
            foreach ($categories as $category) {
                $options[$category->id] = $category->name;
            }
        }
        
        return $options;
    }
}