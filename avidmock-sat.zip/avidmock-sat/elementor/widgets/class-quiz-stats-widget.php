<?php
/**
 * AvidMock SAT Quiz Stats Widget
 * 
 * @package AvidMock_SAT
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AvidMock_SAT_Quiz_Stats_Widget extends \Elementor\Widget_Base {
    
    public function get_name() {
        return 'avidmock-quiz-stats';
    }
    
    public function get_title() {
        return __('Quiz Statistics', AVIDMOCK_SAT_TEXT_DOMAIN);
    }
    
    public function get_icon() {
        return 'eicon-number-field';
    }
    
    public function get_categories() {
        return array('avidmock-sat');
    }
    
    public function get_keywords() {
        return array('stats', 'statistics', 'progress', 'analytics', 'performance');
    }
    
    protected function _register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            array(
                'label' => __('Stats Settings', AVIDMOCK_SAT_TEXT_DOMAIN),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );
        
        $this->add_control(
            'stats_type',
            array(
                'label' => __('Statistics Type', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'overview',
                'options' => array(
                    'overview' => __('Overview', AVIDMOCK_SAT_TEXT_DOMAIN),
                    'category' => __('By Category', AVIDMOCK_SAT_TEXT_DOMAIN),
                    'progress' => __('Progress Chart', AVIDMOCK_SAT_TEXT_DOMAIN),
                    'leaderboard' => __('Leaderboard', AVIDMOCK_SAT_TEXT_DOMAIN),
                ),
            )
        );
        
        $this->add_control(
            'show_user_stats',
            array(
                'label' => __('Show User Stats', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', AVIDMOCK_SAT_TEXT_DOMAIN),
                'label_off' => __('No', AVIDMOCK_SAT_TEXT_DOMAIN),
                'return_value' => 'yes',
                'default' => 'yes',
            )
        );
        
        $this->add_control(
            'stats_period',
            array(
                'label' => __('Time Period', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'all',
                'options' => array(
                    'all' => __('All Time', AVIDMOCK_SAT_TEXT_DOMAIN),
                    'week' => __('Last Week', AVIDMOCK_SAT_TEXT_DOMAIN),
                    'month' => __('Last Month', AVIDMOCK_SAT_TEXT_DOMAIN),
                    'year' => __('Last Year', AVIDMOCK_SAT_TEXT_DOMAIN),
                ),
            )
        );
        
        $this->end_controls_section();
        
        // Style Section
        $this->start_controls_section(
            'style_section',
            array(
                'label' => __('Stats Styling', AVIDMOCK_SAT_TEXT_DOMAIN),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            )
        );
        
        $this->add_control(
            'primary_color',
            array(
                'label' => __('Primary Color', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#e4effb',
            )
        );
        
        $this->add_control(
            'success_color',
            array(
                'label' => __('Success Color', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#def7ea',
            )
        );
        
        $this->add_control(
            'accent_color',
            array(
                'label' => __('Accent Color', AVIDMOCK_SAT_TEXT_DOMAIN),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#eae8f8',
            )
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        $widget_id = $this->get_id();
        $user_id = get_current_user_id();
        
        ?>
        <div id="avidmock-stats-<?php echo esc_attr($widget_id); ?>" class="avidmock-stats-container"
             data-widget-id="<?php echo esc_attr($widget_id); ?>"
             data-stats-type="<?php echo esc_attr($settings['stats_type']); ?>"
             data-period="<?php echo esc_attr($settings['stats_period']); ?>"
             data-user-id="<?php echo esc_attr($user_id); ?>">
            
            <div class="stats-header" style="background-color: <?php echo esc_attr($settings['primary_color']); ?>;">
                <h3 class="stats-title">
                    <?php 
                    switch($settings['stats_type']) {
                        case 'overview':
                            echo __('Performance Overview', AVIDMOCK_SAT_TEXT_DOMAIN);
                            break;
                        case 'category':
                            echo __('Category Performance', AVIDMOCK_SAT_TEXT_DOMAIN);
                            break;
                        case 'progress':
                            echo __('Progress Chart', AVIDMOCK_SAT_TEXT_DOMAIN);
                            break;
                        case 'leaderboard':
                            echo __('Top Performers', AVIDMOCK_SAT_TEXT_DOMAIN);
                            break;
                    }
                    ?>
                </h3>
                <div class="stats-period"><?php echo esc_html($settings['stats_period']); ?></div>
            </div>
            
            <div class="stats-content">
                <?php if ($settings['stats_type'] === 'overview'): ?>
                    <div class="overview-stats">
                        <div class="stat-card" style="background-color: <?php echo esc_attr($settings['primary_color']); ?>;">
                            <div class="stat-value" id="total-quizzes-<?php echo esc_attr($widget_id); ?>">0</div>
                            <div class="stat-label">Total Quizzes</div>
                        </div>
                        <div class="stat-card" style="background-color: <?php echo esc_attr($settings['success_color']); ?>;">
                            <div class="stat-value" id="avg-score-<?php echo esc_attr($widget_id); ?>">0%</div>
                            <div class="stat-label">Average Score</div>
                        </div>
                        <div class="stat-card" style="background-color: <?php echo esc_attr($settings['accent_color']); ?>;">
                            <div class="stat-value" id="total-time-<?php echo esc_attr($widget_id); ?>">0h 0m</div>
                            <div class="stat-label">Study Time</div>
                        </div>
                        <div class="stat-card" style="background-color: <?php echo esc_attr($settings['primary_color']); ?>;">
                            <div class="stat-value" id="streak-<?php echo esc_attr($widget_id); ?>">0</div>
                            <div class="stat-label">Current Streak</div>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if ($settings['stats_type'] === 'category'): ?>
                    <div class="category-stats" id="category-stats-<?php echo esc_attr($widget_id); ?>">
                        <!-- Category stats will be loaded via AJAX -->
                        <div class="loading-placeholder">Loading category statistics...</div>
                    </div>
                <?php endif; ?>
                
                <?php if ($settings['stats_type'] === 'progress'): ?>
                    <div class="progress-chart" id="progress-chart-<?php echo esc_attr($widget_id); ?>">
                        <canvas id="progress-canvas-<?php echo esc_attr($widget_id); ?>" width="400" height="200"></canvas>
                    </div>
                <?php endif; ?>
                
                <?php if ($settings['stats_type'] === 'leaderboard'): ?>
                    <div class="leaderboard" id="leaderboard-<?php echo esc_attr($widget_id); ?>">
                        <!-- Leaderboard will be loaded via AJAX -->
                        <div class="loading-placeholder">Loading leaderboard...</div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <style>
        #avidmock-stats-<?php echo esc_attr($widget_id); ?> {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            margin: 20px 0;
            overflow: hidden;
        }
        
        #avidmock-stats-<?php echo esc_attr($widget_id); ?> .stats-header {
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #e9ecef;
        }
        
        #avidmock-stats-<?php echo esc_attr($widget_id); ?> .stats-title {
            margin: 0;
            font-size: 20px;
            font-weight: 600;
            color: #2c3e50;
        }
        
        #avidmock-stats-<?php echo esc_attr($widget_id); ?> .stats-period {
            background: rgba(255,255,255,0.8);
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 500;
            color: #2c3e50;
            border: 1px solid #000;
        }
        
        #avidmock-stats-<?php echo esc_attr($widget_id); ?> .stats-content {
            padding: 30px;
        }
        
        #avidmock-stats-<?php echo esc_attr($widget_id); ?> .overview-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }
        
        #avidmock-stats-<?php echo esc_attr($widget_id); ?> .stat-card {
            padding: 25px;
            border-radius: 20px;
            border: 1px solid #000;
            text-align: center;
            transition: transform 0.3s ease;
        }
        
        #avidmock-stats-<?php echo esc_attr($widget_id); ?> .stat-card:hover {
            transform: translateY(-5px);
        }
        
        #avidmock-stats-<?php echo esc_attr($widget_id); ?> .stat-value {
            font-size: 32px;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 8px;
        }
        
        #avidmock-stats-<?php echo esc_attr($widget_id); ?> .stat-label {
            font-size: 14px;
            color: #7f8c8d;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        #avidmock-stats-<?php echo esc_attr($widget_id); ?> .loading-placeholder {
            text-align: center;
            padding: 40px;
            color: #7f8c8d;
            font-style: italic;
        }
        
        @media (max-width: 768px) {
            #avidmock-stats-<?php echo esc_attr($widget_id); ?> .overview-stats {
                grid-template-columns: repeat(2, 1fr);
            }
            
            #avidmock-stats-<?php echo esc_attr($widget_id); ?> .stats-header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
        }
        </style>
        <?php
    }
}