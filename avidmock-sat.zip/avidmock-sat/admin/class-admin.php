<?php
/**
 * Admin Class
 * 
 * @package AvidMock_SAT
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AvidMock_SAT_Admin {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('admin_init', array($this, 'init_admin'));
    }
    
    public function add_admin_menu() {
        // Main menu
        add_menu_page(
            __('AvidMock SAT', AVIDMOCK_SAT_TEXT_DOMAIN),
            __('AvidMock SAT', AVIDMOCK_SAT_TEXT_DOMAIN),
            'manage_options',
            'avidmock-sat',
            array($this, 'admin_dashboard'),
            'dashicons-welcome-learn-more',
            30
        );
        
        // Dashboard submenu
        add_submenu_page(
            'avidmock-sat',
            __('Dashboard', AVIDMOCK_SAT_TEXT_DOMAIN),
            __('Dashboard', AVIDMOCK_SAT_TEXT_DOMAIN),
            'manage_options',
            'avidmock-sat',
            array($this, 'admin_dashboard')
        );
        
        // Questions submenu
        add_submenu_page(
            'avidmock-sat',
            __('Questions', AVIDMOCK_SAT_TEXT_DOMAIN),
            __('Questions', AVIDMOCK_SAT_TEXT_DOMAIN),
            'manage_options',
            'avidmock-sat-questions',
            array($this, 'admin_questions')
        );
        
        // Categories submenu
        add_submenu_page(
            'avidmock-sat',
            __('Categories', AVIDMOCK_SAT_TEXT_DOMAIN),
            __('Categories', AVIDMOCK_SAT_TEXT_DOMAIN),
            'manage_options',
            'avidmock-sat-categories',
            array($this, 'admin_categories')
        );
        
        // Statistics submenu
        add_submenu_page(
            'avidmock-sat',
            __('Statistics', AVIDMOCK_SAT_TEXT_DOMAIN),
            __('Statistics', AVIDMOCK_SAT_TEXT_DOMAIN),
            'manage_options',
            'avidmock-sat-stats',
            array($this, 'admin_statistics')
        );
        
        // Settings submenu
        add_submenu_page(
            'avidmock-sat',
            __('Settings', AVIDMOCK_SAT_TEXT_DOMAIN),
            __('Settings', AVIDMOCK_SAT_TEXT_DOMAIN),
            'manage_options',
            'avidmock-sat-settings',
            array($this, 'admin_settings')
        );
    }
    
    public function enqueue_admin_scripts($hook) {
        // Only load on our admin pages
        if (strpos($hook, 'avidmock-sat') === false) {
            return;
        }
        
        wp_enqueue_style(
            'avidmock-sat-admin',
            AVIDMOCK_SAT_CSS_URL . 'admin.css',
            array(),
            AVIDMOCK_SAT_VERSION
        );
        
        wp_enqueue_script(
            'avidmock-sat-admin',
            AVIDMOCK_SAT_JS_URL . 'admin.js',
            array('jquery'),
            AVIDMOCK_SAT_VERSION,
            true
        );
        
        wp_localize_script('avidmock-sat-admin', 'avidmockAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('avidmock_sat_admin_nonce'),
            'strings' => array(
                'confirm_delete' => __('Are you sure you want to delete this item?', AVIDMOCK_SAT_TEXT_DOMAIN),
                'saved' => __('Settings saved successfully!', AVIDMOCK_SAT_TEXT_DOMAIN),
                'error' => __('An error occurred. Please try again.', AVIDMOCK_SAT_TEXT_DOMAIN),
            )
        ));
    }
    
    public function init_admin() {
        // Register settings
        register_setting('avidmock_sat_settings', 'avidmock_sat_options');
    }
    
    public function admin_dashboard() {
        global $wpdb;
        
        // Get statistics
        $total_questions = $wpdb->get_var("SELECT COUNT(*) FROM " . AVIDMOCK_SAT_TABLE_QUESTIONS);
        $total_categories = $wpdb->get_var("SELECT COUNT(*) FROM " . AVIDMOCK_SAT_TABLE_CATEGORIES);
        $total_sessions = $wpdb->get_var("SELECT COUNT(*) FROM " . AVIDMOCK_SAT_TABLE_SESSIONS);
        $active_sessions = $wpdb->get_var("SELECT COUNT(*) FROM " . AVIDMOCK_SAT_TABLE_SESSIONS . " WHERE status = 'active'");
        
        ?>
        <div class="wrap">
            <h1><?php _e('AvidMock SAT Dashboard', AVIDMOCK_SAT_TEXT_DOMAIN); ?></h1>
            
            <div class="avidmock-dashboard">
                <div class="dashboard-widgets">
                    <div class="dashboard-widget">
                        <h3><?php _e('📊 Overview', AVIDMOCK_SAT_TEXT_DOMAIN); ?></h3>
                        <div class="stats-grid">
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $total_questions; ?></div>
                                <div class="stat-label"><?php _e('Total Questions', AVIDMOCK_SAT_TEXT_DOMAIN); ?></div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $total_categories; ?></div>
                                <div class="stat-label"><?php _e('Categories', AVIDMOCK_SAT_TEXT_DOMAIN); ?></div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $total_sessions; ?></div>
                                <div class="stat-label"><?php _e('Total Sessions', AVIDMOCK_SAT_TEXT_DOMAIN); ?></div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $active_sessions; ?></div>
                                <div class="stat-label"><?php _e('Active Sessions', AVIDMOCK_SAT_TEXT_DOMAIN); ?></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="dashboard-widget">
                        <h3><?php _e('🚀 Quick Actions', AVIDMOCK_SAT_TEXT_DOMAIN); ?></h3>
                        <div class="quick-actions">
                            <a href="<?php echo admin_url('admin.php?page=avidmock-sat-questions&action=add'); ?>" class="button button-primary">
                                <?php _e('Add New Question', AVIDMOCK_SAT_TEXT_DOMAIN); ?>
                            </a>
                            <a href="<?php echo admin_url('admin.php?page=avidmock-sat-categories'); ?>" class="button">
                                <?php _e('Manage Categories', AVIDMOCK_SAT_TEXT_DOMAIN); ?>
                            </a>
                            <a href="<?php echo admin_url('admin.php?page=avidmock-sat-stats'); ?>" class="button">
                                <?php _e('View Statistics', AVIDMOCK_SAT_TEXT_DOMAIN); ?>
                            </a>
                        </div>
                    </div>
                    
                    <div class="dashboard-widget">
                        <h3><?php _e('📖 Getting Started', AVIDMOCK_SAT_TEXT_DOMAIN); ?></h3>
                        <div class="getting-started">
                            <ol>
                                <li><?php _e('Create quiz categories', AVIDMOCK_SAT_TEXT_DOMAIN); ?></li>
                                <li><?php _e('Add questions to categories', AVIDMOCK_SAT_TEXT_DOMAIN); ?></li>
                                <li><?php _e('Create a page with Elementor', AVIDMOCK_SAT_TEXT_DOMAIN); ?></li>
                                <li><?php _e('Add the AvidMock Quiz widget', AVIDMOCK_SAT_TEXT_DOMAIN); ?></li>
                                <li><?php _e('Configure widget settings', AVIDMOCK_SAT_TEXT_DOMAIN); ?></li>
                                <li><?php _e('Publish and test your quiz!', AVIDMOCK_SAT_TEXT_DOMAIN); ?></li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            
            <style>
            .avidmock-dashboard {
                margin-top: 20px;
            }
            
            .dashboard-widgets {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 20px;
            }
            
            .dashboard-widget {
                background: white;
                border: 1px solid #c3c4c7;
                border-radius: 8px;
                padding: 20px;
                box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            }
            
            .dashboard-widget h3 {
                margin-top: 0;
                margin-bottom: 15px;
                font-size: 18px;
                color: #2c3e50;
            }
            
            .stats-grid {
                display: grid;
                grid-template-columns: repeat(2, 1fr);
                gap: 15px;
            }
            
            .stat-item {
                text-align: center;
                padding: 15px;
                background: #f8f9fa;
                border-radius: 6px;
            }
            
            .stat-number {
                font-size: 32px;
                font-weight: bold;
                color: #007cba;
                margin-bottom: 5px;
            }
            
            .stat-label {
                font-size: 14px;
                color: #666;
            }
            
            .quick-actions {
                display: flex;
                flex-direction: column;
                gap: 10px;
            }
            
            .getting-started ol {
                padding-left: 20px;
            }
            
            .getting-started li {
                margin-bottom: 8px;
                color: #555;
            }
            </style>
        </div>
        <?php
    }
    
    public function admin_questions() {
        ?>
        <div class="wrap">
            <h1><?php _e('Quiz Questions', AVIDMOCK_SAT_TEXT_DOMAIN); ?></h1>
            <p><?php _e('Manage your quiz questions here. You can add, edit, and organize questions by category.', AVIDMOCK_SAT_TEXT_DOMAIN); ?></p>
            
            <div class="notice notice-info">
                <p><?php _e('💡 Coming soon: Full question management interface with add, edit, and bulk operations.', AVIDMOCK_SAT_TEXT_DOMAIN); ?></p>
            </div>
        </div>
        <?php
    }
    
    public function admin_categories() {
        ?>
        <div class="wrap">
            <h1><?php _e('Quiz Categories', AVIDMOCK_SAT_TEXT_DOMAIN); ?></h1>
            <p><?php _e('Organize your questions into categories for better management and user experience.', AVIDMOCK_SAT_TEXT_DOMAIN); ?></p>
            
            <div class="notice notice-info">
                <p><?php _e('💡 Coming soon: Category management with custom colors and icons.', AVIDMOCK_SAT_TEXT_DOMAIN); ?></p>
            </div>
        </div>
        <?php
    }
    
    public function admin_statistics() {
        ?>
        <div class="wrap">
            <h1><?php _e('Quiz Statistics', AVIDMOCK_SAT_TEXT_DOMAIN); ?></h1>
            <p><?php _e('View detailed analytics about quiz performance and user engagement.', AVIDMOCK_SAT_TEXT_DOMAIN); ?></p>
            
            <div class="notice notice-info">
                <p><?php _e('💡 Coming soon: Detailed charts, user performance reports, and export functionality.', AVIDMOCK_SAT_TEXT_DOMAIN); ?></p>
            </div>
        </div>
        <?php
    }
    
    public function admin_settings() {
        if (isset($_POST['submit'])) {
            // Save settings
            $options = array(
                'default_time_limit' => intval($_POST['default_time_limit']),
                'enable_hints' => isset($_POST['enable_hints']),
                'enable_explanations' => isset($_POST['enable_explanations']),
                'require_login' => isset($_POST['require_login']),
                'primary_color' => sanitize_hex_color($_POST['primary_color']),
                'correct_color' => sanitize_hex_color($_POST['correct_color']),
                'incorrect_color' => sanitize_hex_color($_POST['incorrect_color']),
                'accent_color' => sanitize_hex_color($_POST['accent_color'])
            );
            
            foreach ($options as $key => $value) {
                avidmock_sat_update_option($key, $value);
            }
            
            echo '<div class="notice notice-success"><p>' . __('Settings saved successfully!', AVIDMOCK_SAT_TEXT_DOMAIN) . '</p></div>';
        }
        
        // Get current settings
        $settings = array(
            'default_time_limit' => avidmock_sat_get_option('default_time_limit', 90),
            'enable_hints' => avidmock_sat_get_option('enable_hints', true),
            'enable_explanations' => avidmock_sat_get_option('enable_explanations', true),
            'require_login' => avidmock_sat_get_option('require_login', false),
            'primary_color' => avidmock_sat_get_option('primary_color', '#e4effb'),
            'correct_color' => avidmock_sat_get_option('correct_color', '#def7ea'),
            'incorrect_color' => avidmock_sat_get_option('incorrect_color', '#f8d7da'),
            'accent_color' => avidmock_sat_get_option('accent_color', '#eae8f8')
        );
        
        ?>
        <div class="wrap">
            <h1><?php _e('AvidMock SAT Settings', AVIDMOCK_SAT_TEXT_DOMAIN); ?></h1>
            
            <form method="post" action="">
                <?php wp_nonce_field('avidmock_sat_settings'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Default Time Limit (seconds)', AVIDMOCK_SAT_TEXT_DOMAIN); ?></th>
                        <td>
                            <input type="number" name="default_time_limit" value="<?php echo esc_attr($settings['default_time_limit']); ?>" min="30" max="600" />
                            <p class="description"><?php _e('Default time limit for each question.', AVIDMOCK_SAT_TEXT_DOMAIN); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('Quiz Features', AVIDMOCK_SAT_TEXT_DOMAIN); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="enable_hints" <?php checked($settings['enable_hints']); ?> />
                                <?php _e('Enable hints', AVIDMOCK_SAT_TEXT_DOMAIN); ?>
                            </label><br>
                            
                            <label>
                                <input type="checkbox" name="enable_explanations" <?php checked($settings['enable_explanations']); ?> />
                                <?php _e('Show explanations after wrong answers', AVIDMOCK_SAT_TEXT_DOMAIN); ?>
                            </label><br>
                            
                            <label>
                                <input type="checkbox" name="require_login" <?php checked($settings['require_login']); ?> />
                                <?php _e('Require user login to take quizzes', AVIDMOCK_SAT_TEXT_DOMAIN); ?>
                            </label>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('Color Settings', AVIDMOCK_SAT_TEXT_DOMAIN); ?></th>
                        <td>
                            <label>
                                <?php _e('Primary Color:', AVIDMOCK_SAT_TEXT_DOMAIN); ?>
                                <input type="color" name="primary_color" value="<?php echo esc_attr($settings['primary_color']); ?>" />
                            </label><br><br>
                            
                            <label>
                                <?php _e('Correct Answer Color:', AVIDMOCK_SAT_TEXT_DOMAIN); ?>
                                <input type="color" name="correct_color" value="<?php echo esc_attr($settings['correct_color']); ?>" />
                            </label><br><br>
                            
                            <label>
                                <?php _e('Incorrect Answer Color:', AVIDMOCK_SAT_TEXT_DOMAIN); ?>
                                <input type="color" name="incorrect_color" value="<?php echo esc_attr($settings['incorrect_color']); ?>" />
                            </label><br><br>
                            
                            <label>
                                <?php _e('Accent Color:', AVIDMOCK_SAT_TEXT_DOMAIN); ?>
                                <input type="color" name="accent_color" value="<?php echo esc_attr($settings['accent_color']); ?>" />
                            </label>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
}