<?php
/**
 * Quiz REST API Class
 * 
 * @package AvidMock_SAT
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AvidMock_SAT_Quiz_API {
    
    private $namespace = 'avidmock-sat/v1';
    private $db_manager;
    
    public function __construct() {
        $this->db_manager = new AvidMock_SAT_Database_Manager();
        add_action('rest_api_init', array($this, 'register_routes'));
    }
    
    public function register_routes() {
        // Get categories
        register_rest_route($this->namespace, '/categories', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_categories'),
            'permission_callback' => '__return_true'
        ));
        
        // Get questions
        register_rest_route($this->namespace, '/questions', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_questions'),
            'permission_callback' => '__return_true',
            'args' => array(
                'category_id' => array(
                    'validate_callback' => function($param, $request, $key) {
                        return is_numeric($param);
                    }
                ),
                'limit' => array(
                    'validate_callback' => function($param, $request, $key) {
                        return is_numeric($param) && $param <= 50;
                    }
                )
            )
        ));
        
        // Start quiz session
        register_rest_route($this->namespace, '/quiz/start', array(
            'methods' => 'POST',
            'callback' => array($this, 'start_quiz'),
            'permission_callback' => array($this, 'permissions_check'),
            'args' => array(
                'category_id' => array(
                    'required' => false,
                    'validate_callback' => function($param, $request, $key) {
                        return is_numeric($param);
                    }
                ),
                'question_count' => array(
                    'default' => 10,
                    'validate_callback' => function($param, $request, $key) {
                        return is_numeric($param) && $param > 0 && $param <= 50;
                    }
                )
            )
        ));
        
        // Submit quiz answer
        register_rest_route($this->namespace, '/quiz/answer', array(
            'methods' => 'POST',
            'callback' => array($this, 'submit_answer'),
            'permission_callback' => array($this, 'permissions_check'),
            'args' => array(
                'session_token' => array(
                    'required' => true,
                    'validate_callback' => function($param, $request, $key) {
                        return is_string($param) && !empty($param);
                    }
                ),
                'question_id' => array(
                    'required' => true,
                    'validate_callback' => function($param, $request, $key) {
                        return is_numeric($param);
                    }
                )
            )
        ));
        
        // End quiz session
        register_rest_route($this->namespace, '/quiz/end', array(
            'methods' => 'POST',
            'callback' => array($this, 'end_quiz'),
            'permission_callback' => array($this, 'permissions_check'),
            'args' => array(
                'session_token' => array(
                    'required' => true,
                    'validate_callback' => function($param, $request, $key) {
                        return is_string($param) && !empty($param);
                    }
                )
            )
        ));
        
        // Get user statistics
        register_rest_route($this->namespace, '/stats/(?P<user_id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_user_stats'),
            'permission_callback' => array($this, 'user_stats_permissions_check'),
            'args' => array(
                'user_id' => array(
                    'validate_callback' => function($param, $request, $key) {
                        return is_numeric($param);
                    }
                )
            )
        ));
    }
    
    public function get_categories($request) {
        try {
            $categories = $this->db_manager->get_categories();
            
            $formatted_categories = array();
            foreach ($categories as $category) {
                $formatted_categories[] = array(
                    'id' => intval($category->id),
                    'name' => $category->name,
                    'description' => $category->description,
                    'slug' => $category->slug,
                    'color' => $category->color,
                    'icon' => $category->icon
                );
            }
            
            return new WP_REST_Response($formatted_categories, 200);
            
        } catch (Exception $e) {
            return new WP_Error('api_error', 'Failed to retrieve categories', array('status' => 500));
        }
    }
    
    public function get_questions($request) {
        $category_id = $request->get_param('category_id');
        $limit = $request->get_param('limit') ?: 10;
        
        try {
            $questions = $this->db_manager->get_questions($category_id, $limit);
            
            $formatted_questions = array();
            foreach ($questions as $question) {
                $options = $this->db_manager->get_question_options($question->id);
                
                $formatted_options = array();
                foreach ($options as $option) {
                    $formatted_options[] = array(
                        'id' => intval($option->id),
                        'text' => $option->option_text,
                        'order' => intval($option->option_order)
                    );
                }
                
                $formatted_questions[] = array(
                    'id' => intval($question->id),
                    'text' => $question->question_text,
                    'type' => $question->question_type,
                    'difficulty' => $question->difficulty_level,
                    'time_limit' => intval($question->time_limit),
                    'points' => intval($question->points),
                    'hint' => $question->hint,
                    'options' => $formatted_options
                );
            }
            
            return new WP_REST_Response($formatted_questions, 200);
            
        } catch (Exception $e) {
            return new WP_Error('api_error', 'Failed to retrieve questions', array('status' => 500));
        }
    }
    
    public function start_quiz($request) {
        $category_id = $request->get_param('category_id');
        $question_count = $request->get_param('question_count');
        $user_id = get_current_user_id();
        
        try {
            $session = $this->db_manager->create_quiz_session($user_id, $category_id);
            $questions = $this->db_manager->get_questions($category_id, $question_count);
            
            if (empty($questions)) {
                return new WP_Error('no_questions', 'No questions found', array('status' => 404));
            }
            
            set_transient('avidmock_quiz_questions_' . $session['session_token'], $questions, 3600);
            
            return new WP_REST_Response(array(
                'session_id' => $session['session_id'],
                'session_token' => $session['session_token'],
                'total_questions' => count($questions)
            ), 200);
            
        } catch (Exception $e) {
            return new WP_Error('api_error', 'Failed to start quiz', array('status' => 500));
        }
    }
    
    public function submit_answer($request) {
        $session_token = $request->get_param('session_token');
        $question_id = $request->get_param('question_id');
        $selected_option_id = $request->get_param('selected_option_id');
        $text_answer = $request->get_param('text_answer');
        $time_spent = $request->get_param('time_spent') ?: 0;
        $hint_used = $request->get_param('hint_used') ?: false;
        
        try {
            $session = $this->db_manager->get_quiz_session($session_token);
            if (!$session) {
                return new WP_Error('invalid_session', 'Invalid session', array('status' => 400));
            }
            
            global $wpdb;
            $question = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM " . AVIDMOCK_SAT_TABLE_QUESTIONS . " WHERE id = %d",
                $question_id
            ));
            
            if (!$question) {
                return new WP_Error('question_not_found', 'Question not found', array('status' => 404));
            }
            
            $is_correct = false;
            $correct_option_id = null;
            
            if ($question->question_type === 'multiple_choice' && $selected_option_id) {
                $selected_option = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM " . AVIDMOCK_SAT_TABLE_OPTIONS . " WHERE id = %d",
                    $selected_option_id
                ));
                
                $is_correct = $selected_option && $selected_option->is_correct;
                
                $correct_option = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM " . AVIDMOCK_SAT_TABLE_OPTIONS . " WHERE question_id = %d AND is_correct = 1",
                    $question_id
                ));
                
                $correct_option_id = $correct_option ? $correct_option->id : null;
            }
            
            $points_earned = $is_correct ? $question->points : 0;
            
            $answer_data = array(
                'selected_option_id' => $selected_option_id,
                'text_answer' => $text_answer,
                'is_correct' => $is_correct,
                'points_earned' => $points_earned,
                'time_spent' => $time_spent,
                'hint_used' => $hint_used
            );
            
            $this->db_manager->save_user_answer($session->id, $question_id, $answer_data);
            
            return new WP_REST_Response(array(
                'is_correct' => $is_correct,
                'points_earned' => $points_earned,
                'correct_option_id' => $correct_option_id,
                'explanation' => $question->explanation
            ), 200);
            
        } catch (Exception $e) {
            return new WP_Error('api_error', 'Failed to submit answer', array('status' => 500));
        }
    }
    
    public function end_quiz($request) {
        $session_token = $request->get_param('session_token');
        
        try {
            $session = $this->db_manager->get_quiz_session($session_token);
            if (!$session) {
                return new WP_Error('invalid_session', 'Invalid session', array('status' => 400));
            }
            
            $final_stats = $this->db_manager->complete_quiz_session($session->id);
            delete_transient('avidmock_quiz_questions_' . $session_token);
            
            $score_percentage = 0;
            if ($final_stats->total_questions > 0) {
                $score_percentage = round(($final_stats->correct_answers / $final_stats->total_questions) * 100, 1);
            }
            
            return new WP_REST_Response(array(
                'total_questions' => $final_stats->total_questions,
                'correct_answers' => $final_stats->correct_answers,
                'total_points' => $final_stats->total_points,
                'time_spent' => $final_stats->time_spent,
                'score_percentage' => $score_percentage
            ), 200);
            
        } catch (Exception $e) {
            return new WP_Error('api_error', 'Failed to end quiz', array('status' => 500));
        }
    }
    
    public function get_user_stats($request) {
        $user_id = $request->get_param('user_id');
        
        try {
            $stats = $this->db_manager->get_user_stats($user_id);
            
            $formatted_stats = array();
            foreach ($stats as $stat) {
                $formatted_stats[] = array(
                    'category_id' => intval($stat->category_id),
                    'total_questions' => intval($stat->total_questions_attempted),
                    'correct_answers' => intval($stat->total_correct_answers),
                    'accuracy' => floatval($stat->accuracy_percentage),
                    'total_time' => intval($stat->total_time_spent),
                    'average_time' => floatval($stat->average_time_per_question),
                    'best_score' => intval($stat->best_score),
                    'total_sessions' => intval($stat->total_sessions)
                );
            }
            
            return new WP_REST_Response($formatted_stats, 200);
            
        } catch (Exception $e) {
            return new WP_Error('api_error', 'Failed to retrieve stats', array('status' => 500));
        }
    }
    
    public function permissions_check() {
        // Allow all users (including guests) for now
        return true;
    }
    
    public function user_stats_permissions_check($request) {
        $user_id = $request->get_param('user_id');
        $current_user_id = get_current_user_id();
        
        // Users can only access their own stats, or admins can access all
        return $current_user_id == $user_id || current_user_can('manage_options');
    }
}