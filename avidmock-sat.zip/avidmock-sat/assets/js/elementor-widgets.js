/**
 * AvidMock SAT Elementor Widgets JavaScript
 * 
 * Complete quiz functionality for Elementor widgets
 */

class AvidMockQuiz {
    constructor(widgetId) {
        this.widgetId = widgetId;
        this.container = document.getElementById('avidmock-quiz-' + widgetId);
        
        if (!this.container) {
            console.error('Quiz container not found for widget:', widgetId);
            return;
        }
        
        this.currentQuestion = 0;
        this.questions = [];
        this.userAnswers = [];
        this.sessionId = null;
        this.sessionToken = null;
        this.timer = null;
        this.timeLeft = 0;
        this.isSubmitted = false;
        this.hintUsed = false;
        this.startTime = null;
        
        // Get settings from data attributes
        this.settings = {
            category: this.container.dataset.category || '',
            questionCount: parseInt(this.container.dataset.questionCount) || 10,
            timeLimit: parseInt(this.container.dataset.timeLimit) || 90,
            showTimer: this.container.dataset.showTimer === 'yes',
            showHint: this.container.dataset.showHint === 'yes'
        };
        
        this.init();
    }
    
    async init() {
        this.bindEvents();
        await this.startQuiz();
    }
    
    bindEvents() {
        // Answer selection for multiple choice
        this.container.addEventListener('click', (e) => {
            if (e.target.closest('.choice') && !this.isSubmitted) {
                this.selectAnswer(e.target.closest('.choice'));
            }
        });
        
        // Open-ended answer input
        const openAnswerText = this.container.querySelector('#open-answer-text-' + this.widgetId);
        if (openAnswerText) {
            openAnswerText.addEventListener('input', () => {
                const submitBtn = this.container.querySelector('#submit-btn-' + this.widgetId);
                if (submitBtn) {
                    submitBtn.disabled = !openAnswerText.value.trim();
                }
            });
        }
        
        // Submit button
        const submitBtn = this.container.querySelector('#submit-btn-' + this.widgetId);
        if (submitBtn) {
            submitBtn.addEventListener('click', () => this.submitAnswer());
        }
        
        // Next button
        const nextBtn = this.container.querySelector('#next-btn-' + this.widgetId);
        if (nextBtn) {
            nextBtn.addEventListener('click', () => this.nextQuestion());
        }
        
        // Hint button
        const hintBtn = this.container.querySelector('#hint-btn-' + this.widgetId);
        if (hintBtn) {
            hintBtn.addEventListener('click', () => this.showHint());
        }
        
        // Results modal buttons
        const restartBtn = this.container.querySelector('#restart-btn-' + this.widgetId);
        if (restartBtn) {
            restartBtn.addEventListener('click', () => this.restartQuiz());
        }
        
        const closeBtn = this.container.querySelector('#close-btn-' + this.widgetId);
        if (closeBtn) {
            closeBtn.addEventListener('click', () => this.closeResults());
        }
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (!this.isQuizActive()) return;
            
            // A, B, C, D keys for answer selection
            if (e.key >= 'a' && e.key <= 'd' && !this.isSubmitted) {
                const choiceIndex = e.key.charCodeAt(0) - 97; // a=0, b=1, c=2, d=3
                const choices = this.container.querySelectorAll('.choice');
                if (choices[choiceIndex] && choices[choiceIndex].style.display !== 'none') {
                    this.selectAnswer(choices[choiceIndex]);
                }
            }
            
            // Enter key for submit/next
            if (e.key === 'Enter') {
                if (!this.isSubmitted) {
                    const submitBtn = this.container.querySelector('#submit-btn-' + this.widgetId);
                    if (submitBtn && !submitBtn.disabled) {
                        this.submitAnswer();
                    }
                } else {
                    const nextBtn = this.container.querySelector('#next-btn-' + this.widgetId);
                    if (nextBtn && nextBtn.classList.contains('show')) {
                        this.nextQuestion();
                    }
                }
            }
        });
    }
    
    isQuizActive() {
        const loadingEl = this.container.querySelector('#quiz-loading-' + this.widgetId);
        const resultsModal = this.container.querySelector('#results-modal-' + this.widgetId);
        
        return loadingEl.style.display === 'none' && 
               resultsModal.style.display === 'none';
    }
    
    async startQuiz() {
        this.showLoading(true);
        this.startTime = Date.now();
        
        try {
            const response = await this.apiCall('avidmock_start_quiz', {
                category_id: this.settings.category || null,
                question_count: this.settings.questionCount
            });
            
            if (response.success) {
                this.sessionId = response.data.session_id;
                this.sessionToken = response.data.session_token;
                this.totalQuestions = response.data.total_questions;
                
                // Update total questions display
                const totalEl = this.container.querySelector('#total-questions-' + this.widgetId);
                if (totalEl) {
                    totalEl.textContent = this.totalQuestions;
                }
                
                await this.loadQuestion(0);
            } else {
                this.showError('Failed to start quiz: ' + (response.data?.message || 'Unknown error'));
            }
        } catch (error) {
            this.showError('Error starting quiz: ' + error.message);
        }
        
        this.showLoading(false);
    }
    
    async loadQuestion(index) {
        if (index >= this.totalQuestions) {
            await this.showResults();
            return;
        }
        
        try {
            const response = await this.apiCall('avidmock_get_question', {
                session_token: this.sessionToken,
                question_index: index
            });
            
            if (response.success) {
                this.currentQuestion = index;
                this.displayQuestion(response.data);
                this.resetControls();
                
                if (this.settings.showTimer) {
                    this.startTimer(response.data.time_limit || this.settings.timeLimit);
                }
                
                this.hideExplanation();
            } else {
                this.showError('Failed to load question: ' + (response.data?.message || 'Unknown error'));
            }
        } catch (error) {
            this.showError('Error loading question: ' + error.message);
        }
    }
    
    displayQuestion(questionData) {
        // Update question counter
        const currentQuestionEl = this.container.querySelector('#current-question-' + this.widgetId);
        if (currentQuestionEl) {
            currentQuestionEl.textContent = this.currentQuestion + 1;
        }
        
        // Update question text
        const questionTextEl = this.container.querySelector('#question-text-' + this.widgetId);
        if (questionTextEl) {
            questionTextEl.innerHTML = questionData.text;
        }
        
        // Update answer choices based on question type
        if (questionData.type === 'multiple_choice') {
            this.loadMultipleChoice(questionData);
        } else {
            this.loadOpenEnded(questionData);
        }
        
        // Show question content
        const loadingEl = this.container.querySelector('#quiz-loading-' + this.widgetId);
        const contentEl = this.container.querySelector('#question-content-' + this.widgetId);
        
        if (loadingEl) loadingEl.style.display = 'none';
        if (contentEl) contentEl.style.display = 'block';
        
        // Store current question data
        this.currentQuestionData = questionData;
    }
    
    loadMultipleChoice(questionData) {
        const answersContainer = this.container.querySelector('#answer-choices-' + this.widgetId);
        const openContainer = this.container.querySelector('#open-answer-' + this.widgetId);
        
        if (answersContainer) answersContainer.style.display = 'flex';
        if (openContainer) openContainer.style.display = 'none';
        
        const choices = this.container.querySelectorAll('.choice');
        choices.forEach((choice, index) => {
            if (questionData.options[index]) {
                choice.style.display = 'flex';
                const textEl = choice.querySelector('.choice-text');
                if (textEl) {
                    textEl.textContent = questionData.options[index].text;
                }
                choice.dataset.optionId = questionData.options[index].id;
                choice.className = 'choice';
            } else {
                choice.style.display = 'none';
            }
        });
    }
    
    loadOpenEnded(questionData) {
        const answersContainer = this.container.querySelector('#answer-choices-' + this.widgetId);
        const openContainer = this.container.querySelector('#open-answer-' + this.widgetId);
        
        if (answersContainer) answersContainer.style.display = 'none';
        if (openContainer) openContainer.style.display = 'block';
        
        const textarea = this.container.querySelector('#open-answer-text-' + this.widgetId);
        if (textarea) {
            textarea.value = '';
            textarea.focus();
        }
    }
    
    selectAnswer(answerElement) {
        // Remove previous selections
        this.container.querySelectorAll('.choice').forEach(el => {
            el.classList.remove('selected');
        });
        
        // Select current answer
        answerElement.classList.add('selected');
        
        // Enable submit button
        const submitBtn = this.container.querySelector('#submit-btn-' + this.widgetId);
        if (submitBtn) {
            submitBtn.disabled = false;
        }
    }
    
    async submitAnswer() {
        if (this.isSubmitted) return;
        
        let answerData = {};
        
        if (this.currentQuestionData.type === 'multiple_choice') {
            const selectedOption = this.container.querySelector('.choice.selected');
            if (!selectedOption) {
                this.showNotification(avidmockSat?.strings?.selectAnswer || 'Please select an answer', 'warning');
                return;
            }
            answerData.selected_option_id = selectedOption.dataset.optionId;
        } else {
            const textAnswer = this.container.querySelector('#open-answer-text-' + this.widgetId);
            if (!textAnswer || !textAnswer.value.trim()) {
                this.showNotification('Please provide an answer', 'warning');
                return;
            }
            answerData.text_answer = textAnswer.value.trim();
        }
        
        this.isSubmitted = true;
        this.stopTimer();
        
        // Calculate time spent
        const timeSpent = (this.settings.timeLimit - this.timeLeft) || 0;
        
        // Show loading state on submit button
        const submitBtn = this.container.querySelector('#submit-btn-' + this.widgetId);
        if (submitBtn) {
            submitBtn.textContent = 'Submitting...';
            submitBtn.disabled = true;
        }
        
        try {
            const response = await this.apiCall('avidmock_submit_answer', {
                session_token: this.sessionToken,
                question_id: this.currentQuestionData.id,
                time_spent: timeSpent,
                hint_used: this.hintUsed,
                ...answerData
            });
            
            if (response.success) {
                this.showAnswerResult(response.data);
                this.userAnswers.push({
                    ...response.data,
                    question_id: this.currentQuestionData.id,
                    time_spent: timeSpent
                });
            } else {
                this.showError('Failed to submit answer: ' + (response.data?.message || 'Unknown error'));
                this.isSubmitted = false; // Allow retry
            }
        } catch (error) {
            this.showError('Error submitting answer: ' + error.message);
            this.isSubmitted = false; // Allow retry
        }
    }
    
    showAnswerResult(result) {
        if (this.currentQuestionData.type === 'multiple_choice') {
            // Highlight correct and incorrect answers
            this.container.querySelectorAll('.choice').forEach(choice => {
                const optionId = parseInt(choice.dataset.optionId);
                const isSelected = choice.classList.contains('selected');
                
                if (optionId === result.correct_option_id) {
                    choice.classList.add('correct');
                } else if (isSelected && !result.is_correct) {
                    choice.classList.add('incorrect');
                }
                
                choice.classList.add('disabled');
            });
            
            // Show explanation if answer is wrong
            if (!result.is_correct && result.explanation) {
                this.showExplanation(result.explanation);
            }
        }
        
        // Update button states
        const submitBtn = this.container.querySelector('#submit-btn-' + this.widgetId);
        const nextBtn = this.container.querySelector('#next-btn-' + this.widgetId);
        
        if (submitBtn) submitBtn.style.display = 'none';
        if (nextBtn) nextBtn.classList.add('show');
        
        // Show result notification
        const message = result.is_correct ? '✅ Correct!' : '❌ Incorrect';
        this.showNotification(message, result.is_correct ? 'success' : 'error');
    }
    
    showExplanation(explanation) {
        const explanationSection = this.container.querySelector('#explanation-section-' + this.widgetId);
        const explanationContent = this.container.querySelector('#explanation-content-' + this.widgetId);
        
        if (explanationSection && explanationContent) {
            explanationContent.innerHTML = explanation;
            explanationSection.style.display = 'block';
        }
    }
    
    hideExplanation() {
        const explanationSection = this.container.querySelector('#explanation-section-' + this.widgetId);
        if (explanationSection) {
            explanationSection.style.display = 'none';
        }
    }
    
    async nextQuestion() {
        this.hideExplanation();
        await this.loadQuestion(this.currentQuestion + 1);
    }
    
    resetControls() {
        this.isSubmitted = false;
        this.hintUsed = false;
        
        // Reset buttons
        const submitBtn = this.container.querySelector('#submit-btn-' + this.widgetId);
        const nextBtn = this.container.querySelector('#next-btn-' + this.widgetId);
        const hintBtn = this.container.querySelector('#hint-btn-' + this.widgetId);
        const hintDisplay = this.container.querySelector('#hint-display-' + this.widgetId);
        
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.style.display = 'block';
            submitBtn.textContent = 'Submit';
        }
        if (nextBtn) nextBtn.classList.remove('show');
        if (hintBtn) hintBtn.disabled = false;
        if (hintDisplay) hintDisplay.style.display = 'none';
        
        // Clear answer selections
        this.container.querySelectorAll('.choice').forEach(choice => {
            choice.classList.remove('selected', 'correct', 'incorrect', 'disabled');
        });
    }
    
    startTimer(timeLimit) {
        this.timeLeft = timeLimit || this.settings.timeLimit;
        
        if (this.timer) clearInterval(this.timer);
        
        this.updateTimerDisplay();
        
        this.timer = setInterval(() => {
            this.timeLeft--;
            this.updateTimerDisplay();
            
            if (this.timeLeft <= 10) {
                const timerEl = this.container.querySelector('#timer-' + this.widgetId);
                if (timerEl) timerEl.classList.add('warning');
            }
            
            if (this.timeLeft <= 0) {
                this.stopTimer();
                this.showNotification(avidmockSat?.strings?.timeUp || 'Time is up!', 'warning');
                this.submitAnswer();
            }
        }, 1000);
    }
    
    stopTimer() {
        if (this.timer) {
            clearInterval(this.timer);
            this.timer = null;
        }
        
        const timerEl = this.container.querySelector('#timer-' + this.widgetId);
        if (timerEl) timerEl.classList.remove('warning');
    }
    
    updateTimerDisplay() {
        const minutes = Math.floor(this.timeLeft / 60);
        const seconds = this.timeLeft % 60;
        const display = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        
        const timerDisplay = this.container.querySelector('#timer-display-' + this.widgetId);
        if (timerDisplay) {
            timerDisplay.textContent = display;
        }
    }
    
    async showHint() {
        if (this.hintUsed) return;
        
        this.hintUsed = true;
        
        const hintDisplay = this.container.querySelector('#hint-display-' + this.widgetId);
        const hintText = this.container.querySelector('#hint-text-' + this.widgetId);
        const hintBtn = this.container.querySelector('#hint-btn-' + this.widgetId);
        
        if (hintText && this.currentQuestionData.hint) {
            hintText.textContent = this.currentQuestionData.hint;
        }
        
        if (hintDisplay) hintDisplay.style.display = 'block';
        if (hintBtn) hintBtn.disabled = true;
        
        this.showNotification('💡 Hint revealed!', 'info');
    }
    
    async showResults() {
        this.stopTimer();
        
        try {
            const response = await this.apiCall('avidmock_end_quiz', {
                session_token: this.sessionToken
            });
            
            if (response.success) {
                this.displayResults(response.data);
            } else {
                this.showError('Failed to get results: ' + (response.data?.message || 'Unknown error'));
            }
        } catch (error) {
            this.showError('Error getting results: ' + error.message);
        }
    }
    
    displayResults(results) {
        const modal = this.container.querySelector('#results-modal-' + this.widgetId);
        const scoreEl = this.container.querySelector('#final-score-' + this.widgetId);
        const correctEl = this.container.querySelector('#final-correct-' + this.widgetId);
        const timeEl = this.container.querySelector('#final-time-' + this.widgetId);
        
        if (scoreEl) scoreEl.textContent = results.score_percentage + '%';
        if (correctEl) correctEl.textContent = `${results.correct_answers}/${results.total_questions}`;
        if (timeEl) {
            const totalTime = Math.floor((Date.now() - this.startTime) / 1000);
            const minutes = Math.floor(totalTime / 60);
            const seconds = totalTime % 60;
            timeEl.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        }
        
        if (modal) modal.style.display = 'flex';
        
        // Trigger celebration if score is good
        if (results.score_percentage >= 80) {
            this.celebrate();
        }
    }
    
    celebrate() {
        // Simple celebration effect
        const modal = this.container.querySelector('#results-modal-' + this.widgetId);
        if (modal) {
            modal.style.animation = 'bounce 0.6s ease-in-out';
            setTimeout(() => {
                modal.style.animation = '';
            }, 600);
        }
    }
    
    restartQuiz() {
        this.closeResults();
        this.currentQuestion = 0;
        this.userAnswers = [];
        this.sessionId = null;
        this.sessionToken = null;
        this.hideExplanation();
        this.startQuiz();
    }
    
    closeResults() {
        const modal = this.container.querySelector('#results-modal-' + this.widgetId);
        if (modal) modal.style.display = 'none';
    }
    
    showLoading(show) {
        const loadingEl = this.container.querySelector('#quiz-loading-' + this.widgetId);
        const contentEl = this.container.querySelector('#question-content-' + this.widgetId);
        
        if (loadingEl) loadingEl.style.display = show ? 'block' : 'none';
        if (contentEl) contentEl.style.display = show ? 'none' : 'block';
    }
    
    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `quiz-notification quiz-notification-${type}`;
        notification.textContent = message;
        
        // Style the notification
        Object.assign(notification.style, {
            position: 'fixed',
            top: '20px',
            right: '20px',
            padding: '12px 20px',
            borderRadius: '20px',
            border: '1px solid #000',
            background: type === 'success' ? '#def7ea' : 
                       type === 'error' ? '#f8d7da' : 
                       type === 'warning' ? '#fff3cd' : '#e4effb',
            color: '#2c3e50',
            fontWeight: '600',
            zIndex: '10000',
            animation: 'slideInRight 0.3s ease-out',
            maxWidth: '300px',
            wordWrap: 'break-word'
        });
        
        document.body.appendChild(notification);
        
        // Remove after 3 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease-in';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }
    
    showError(message) {
        console.error('AvidMock Quiz Error:', message);
        this.showNotification(message, 'error');
    }
    
    async apiCall(action, data) {
        const formData = new FormData();
        formData.append('action', action);
        formData.append('nonce', avidmockSat?.nonce || '');
        
        for (const [key, value] of Object.entries(data)) {
            if (value !== null && value !== undefined) {
                formData.append(key, value);
            }
        }
        
        try {
            const response = await fetch(avidmockSat?.ajaxUrl || '/wp-admin/admin-ajax.php', {
                method: 'POST',
                body: formData
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const result = await response.json();
            return result;
        } catch (error) {
            console.error('API call failed:', error);
            throw error;
        }
    }
}

// CSS for notifications
const notificationStyles = `
@keyframes slideInRight {
    from { transform: translateX(100%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
}

@keyframes slideOutRight {
    from { transform: translateX(0); opacity: 1; }
    to { transform: translateX(100%); opacity: 0; }
}

@keyframes bounce {
    0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
    40% { transform: translateY(-10px); }
    60% { transform: translateY(-5px); }
}
`;

// Inject notification styles
if (!document.getElementById('avidmock-notification-styles')) {
    const styleSheet = document.createElement('style');
    styleSheet.id = 'avidmock-notification-styles';
    styleSheet.textContent = notificationStyles;
    document.head.appendChild(styleSheet);
}

// Initialize quiz widgets when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Make class globally available
    window.AvidMockQuiz = AvidMockQuiz;
    
    // Auto-initialize any quiz widgets found on page
    const quizContainers = document.querySelectorAll('[id^="avidmock-quiz-"]');
    quizContainers.forEach(container => {
        const widgetId = container.id.replace('avidmock-quiz-', '');
        if (!container.dataset.initialized) {
            new AvidMockQuiz(widgetId);
            container.dataset.initialized = 'true';
        }
    });
});

// Re-initialize widgets when Elementor preview updates
if (window.elementorFrontend) {
    window.elementorFrontend.hooks.addAction('frontend/element_ready/avidmock-quiz.default', function($scope) {
        const container = $scope[0].querySelector('[id^="avidmock-quiz-"]');
        if (container && !container.dataset.initialized) {
            const widgetId = container.id.replace('avidmock-quiz-', '');
            new AvidMockQuiz(widgetId);
            container.dataset.initialized = 'true';
        }
    });
}Data);
        }
        
        // Show question content
        const loadingEl = this.container.querySelector('#quiz-loading-' + this.widgetId);
        const contentEl = this.container.querySelector('#question-content-' + this.widgetId);
        
        if (loadingEl) loadingEl.style.display = 'none';
        if (contentEl) contentEl.style.display = 'block';
        
        // Store current question data
        this.currentQuestionData = questionData;
    }
    
    loadMultipleChoice(questionData) {
        const answersContainer = this.container.querySelector('#answer-choices-' + this.widgetId);
        const openContainer = this.container.querySelector('#open-answer-' + this.widgetId);
        
        if (answersContainer) answersContainer.style.display = 'flex';
        if (openContainer) openContainer.style.display = 'none';
        
        const choices = this.container.querySelectorAll('.choice');
        choices.forEach((choice, index) => {
            if (questionData.options[index]) {
                choice.style.display = 'flex';
                const textEl = choice.querySelector('.choice-text');
                if (textEl) {
                    textEl.textContent = questionData.options[index].text;
                }
                choice.dataset.optionId = questionData.options[index].id;
                choice.className = 'choice';
            } else {
                choice.style.display = 'none';
            }
        });
    }
    
    loadOpenEnded(questionData) {
        const answersContainer = this.container.querySelector('#answer-choices-' + this.widgetId);
        const openContainer = this.container.querySelector('#open-answer-' + this.widgetId);
        
        if (answersContainer) answersContainer.style.display = 'none';
        if (openContainer) openContainer.style.display = 'block';
        
        const textarea = this.container.querySelector('#open-answer-text-' + this.widgetId);
        if (textarea) {
            textarea.value = '';
        }
    }
    
    selectAnswer(answerElement) {
        // Remove previous selections
        this.container.querySelectorAll('.choice').forEach(el => {
            el.classList.remove('selected');
        });
        
        // Select current answer
        answerElement.classList.add('selected');
        
        // Enable submit button
        const submitBtn = this.container.querySelector('#submit-btn-' + this.widgetId);
        if (submitBtn) {
            submitBtn.disabled = false;
        }
    }
    
    async submitAnswer() {
        if (this.isSubmitted) return;
        
        let answerData = {};
        
        if (this.currentQuestionData.type === 'multiple_choice') {
            const selectedOption = this.container.querySelector('.choice.selected');
            if (!selectedOption) {
                alert(avidmockSat.strings.selectAnswer || 'Please select an answer');
                return;
            }
            answerData.selected_option_id = selectedOption.dataset.optionId;
        } else {
            const textAnswer = this.container.querySelector('#open-answer-text-' + this.widgetId);
            if (!textAnswer || !textAnswer.value.trim()) {
                alert('Please provide an answer');
                return;
            }
            answerData.text_answer = textAnswer.value.trim();
        }
        
        this.isSubmitted = true;
        this.stopTimer();
        
        // Calculate time spent
        const timeSpent = this.settings.timeLimit - this.timeLeft;
        
        try {
            const response = await this.apiCall('avidmock_submit_answer', {
                session_token: this.sessionToken,
                question_id: this.currentQuestionData.id,
                time_spent: timeSpent,
                hint_used: this.hintUsed,
                ...answerData
            });
            
            if (response.success) {
                this.showAnswerResult(response.data);
                this.userAnswers.push(response.data);
            } else {
                this.showError('Failed to submit answer: ' + response.data.message);
            }
        } catch (error) {
            this.showError('Error submitting answer: ' + error.message);
        }
    }
    
    showAnswerResult(result) {
        if (this.currentQuestionData.type === 'multiple_choice') {
            // Highlight correct and incorrect answers
            this.container.querySelectorAll('.choice').forEach(choice => {
                const optionId = parseInt(choice.dataset.optionId);
                const isSelected = choice.classList.contains('selected');
                
                if (optionId === result.correct_option_id) {
                    choice.classList.add('correct');
                } else if (isSelected && !result.is_correct) {
                    choice.classList.add('incorrect');
                }
                
                choice.classList.add('disabled');
            });
            
            // Show explanation if answer is wrong
            if (!result.is_correct) {
                this.showExplanation(result.explanation);
            }
        }
        
        // Update button states
        const submitBtn = this.container.querySelector('#submit-btn-' + this.widgetId);
        const nextBtn = this.container.querySelector('#next-btn-' + this.widgetId);
        
        if (submitBtn) submitBtn.style.display = 'none';
        if (nextBtn) nextBtn.classList.add('show');
    }
    
    showExplanation(explanation) {
        const explanationSection = this.container.querySelector('#explanation-section-' + this.widgetId);
        const explanationContent = this.container.querySelector('#explanation-content-' + this.widgetId);
        
        if (explanationSection && explanationContent) {
            explanationContent.innerHTML = explanation;
            explanationSection.style.display = 'block';
        }
    }
    
    async nextQuestion() {
        this.hideExplanation();
        await this.loadQuestion(this.currentQuestion + 1);
    }
    
    hideExplanation() {
        const explanationSection = this.container.querySelector('#explanation-section-' + this.widgetId);
        if (explanationSection) {
            explanationSection.style.display = 'none';
        }
    }
    
    resetControls() {
        this.isSubmitted = false;
        this.hintUsed = false;
        
        // Reset buttons
        const submitBtn = this.container.querySelector('#submit-btn-' + this.widgetId);
        const nextBtn = this.container.querySelector('#next-btn-' + this.widgetId);
        const hintBtn = this.container.querySelector('#hint-btn-' + this.widgetId);
        const hintDisplay = this.container.querySelector('#hint-display-' + this.widgetId);
        
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.style.display = 'block';
        }
        if (nextBtn) nextBtn.classList.remove('show');
        if (hintBtn) hintBtn.disabled = false;
        if (hintDisplay) hintDisplay.classList.remove('show');
    }
    
    startTimer(timeLimit) {
        this.timeLeft = timeLimit || this.settings.timeLimit;
        
        if (this.timer) clearInterval(this.timer);
        
        this.timer = setInterval(() => {
            this.timeLeft--;
            this.updateTimerDisplay();
            
            if (this.timeLeft <= 10) {
                const timerEl = this.container.querySelector('#timer-' + this.widgetId);
                if (timerEl) timerEl.classList.add('warning');
            }
            
            if (this.timeLeft <= 0) {
                this.stopTimer();
                this.submitAnswer();
            }
        }, 1000);
    }
    
    stopTimer() {
        if (this.timer) {
            clearInterval(this.timer);
            this.timer = null;
        }
        
        const timerEl = this.container.querySelector('#timer-' + this.widgetId);
        if (timerEl) timerEl.classList.remove('warning');
    }
    
    updateTimerDisplay() {
        const minutes = Math.floor(this.timeLeft / 60);
        const seconds = this.timeLeft % 60;
        const display = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        
        const timerDisplay = this.container.querySelector('#timer-display-' + this.widgetId);
        if (timerDisplay) {
            timerDisplay.textContent = display;
        }
    }
    
    async showHint() {
        if (this.hintUsed) return;
        
        this.hintUsed = true;
        
        const hintDisplay = this.container.querySelector('#hint-display-' + this.widgetId);
        const hintText = this.container.querySelector('#hint-text-' + this.widgetId);
        const hintBtn = this.container.querySelector('#hint-btn-' + this.widgetId);
        
        if (hintText && this.currentQuestionData.hint) {
            hintText.textContent = this.currentQuestionData.hint;
        }
        
        if (hintDisplay) hintDisplay.style.display = 'block';
        if (hintBtn) hintBtn.disabled = true;
    }
    
    async showResults() {
        try {
            const response = await this.apiCall('avidmock_end_quiz', {
                session_token: this.sessionToken
            });
            
            if (response.success) {
                this.displayResults(response.data);
            } else {
                this.showError('Failed to get results: ' + response.data.message);
            }
        } catch (error) {
            this.showError('Error getting results: ' + error.message);
        }
    }
    
    displayResults(results) {
        const modal = this.container.querySelector('#results-modal-' + this.widgetId);
        const scoreEl = this.container.querySelector('#final-score-' + this.widgetId);
        const correctEl = this.container.querySelector('#final-correct-' + this.widgetId);
        const timeEl = this.container.querySelector('#final-time-' + this.widgetId);
        
        if (scoreEl) scoreEl.textContent = results.score_percentage + '%';
        if (correctEl) correctEl.textContent = `${results.correct_answers}/${results.total_questions}`;
        if (timeEl) timeEl.textContent = results.time_formatted || '00:00';
        
        if (modal) modal.style.display = 'flex';
    }
    
    restartQuiz() {
        this.closeResults();
        this.currentQuestion = 0;
        this.userAnswers = [];
        this.startQuiz();
    }
    
    closeResults() {
        const modal = this.container.querySelector('#results-modal-' + this.widgetId);
        if (modal) modal.style.display = 'none';
    }
    
    showLoading(show) {
        const loadingEl = this.container.querySelector('#quiz-loading-' + this.widgetId);
        const contentEl = this.container.querySelector('#question-content-' + this.widgetId);
        
        if (loadingEl) loadingEl.style.display = show ? 'block' : 'none';
        if (contentEl) contentEl.style.display = show ? 'none' : 'block';
    }
    
    showError(message) {
        console.error('AvidMock Quiz Error:', message);
        alert(message);
    }
    
    async apiCall(action, data) {
        const formData = new FormData();
        formData.append('action', action);
        formData.append('nonce', avidmockSat.nonce);
        
        for (const [key, value] of Object.entries(data)) {
            formData.append(key, value);
        }
        
        const response = await fetch(avidmockSat.ajaxUrl, {
            method: 'POST',
            body: formData
        });
        
        return await response.json();
    }
}

// Initialize quiz widgets when page loads
document.addEventListener('DOMContentLoaded', function() {
    // This will be called from the widget render method
    window.AvidMockQuiz = AvidMockQuiz;
});
