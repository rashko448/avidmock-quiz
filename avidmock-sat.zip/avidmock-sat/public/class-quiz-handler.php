<?php
/**
 * Quiz Handler Class
 * 
 * @package AvidMock_SAT
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AvidMock_SAT_Quiz_Handler {
    
    private $db_manager;
    
    public function __construct() {
        $this->db_manager = new AvidMock_SAT_Database_Manager();
    }
    
    /**
     * Get quiz data for frontend
     * 
     * @param array $args
     * @return array
     */
    public function get_quiz_data($args = array()) {
        $defaults = array(
            'category_id' => null,
            'question_count' => 10,
            'difficulty' => null,
            'randomize' => true
        );
        
        $args = wp_parse_args($args, $defaults);
        
        // Get questions
        $questions = $this->db_manager->get_questions($args['category_id'], $args['question_count']);
        
        // Format questions for frontend
        $formatted_questions = array();
        foreach ($questions as $question) {
            $options = $this->db_manager->get_question_options($question->id);
            
            $formatted_question = array(
                'id' => $question->id,
                'text' => $question->question_text,
                'type' => $question->question_type,
                'difficulty' => $question->difficulty_level,
                'time_limit' => $question->time_limit,
                'points' => $question->points,
                'hint' => $question->hint,
                'options' => array()
            );
            
            foreach ($options as $option) {
                $formatted_question['options'][] = array(
                    'id' => $option->id,
                    'text' => $option->option_text,
                    'order' => $option->option_order
                );
            }
            
            // Randomize options if requested
            if ($args['randomize'] && $question->question_type === 'multiple_choice') {
                shuffle($formatted_question['options']);
            }
            
            $formatted_questions[] = $formatted_question;
        }
        
        return $formatted_questions;
    }
    
    /**
     * Validate quiz answer
     * 
     * @param int $question_id
     * @param mixed $answer
     * @return array
     */
    public function validate_answer($question_id, $answer) {
        global $wpdb;
        
        $question = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . AVIDMOCK_SAT_TABLE_QUESTIONS . " WHERE id = %d",
            $question_id
        ));
        
        if (!$question) {
            return array(
                'is_correct' => false,
                'error' => __('Question not found.', AVIDMOCK_SAT_TEXT_DOMAIN)
            );
        }
        
        $is_correct = false;
        $correct_answer = null;
        
        if ($question->question_type === 'multiple_choice') {
            // Get correct option
            $correct_option = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM " . AVIDMOCK_SAT_TABLE_OPTIONS . " WHERE question_id = %d AND is_correct = 1",
                $question_id
            ));
            
            if ($correct_option) {
                $correct_answer = $correct_option->id;
                $is_correct = ($answer == $correct_option->id);
            }
        } else {
            // For open-ended questions, this would need custom validation logic
            // For now, we'll just mark as submitted
            $is_correct = !empty($answer);
            $correct_answer = 'open_ended';
        }
        
        return array(
            'is_correct' => $is_correct,
            'correct_answer' => $correct_answer,
            'explanation' => $question->explanation,
            'points' => $is_correct ? $question->points : 0
        );
    }
    
    /**
     * Calculate quiz results
     * 
     * @param array $answers
     * @return array
     */
    public function calculate_results($answers) {
        $total_questions = count($answers);
        $correct_answers = 0;
        $total_points = 0;
        $total_time = 0;
        
        foreach ($answers as $answer) {
            if (isset($answer['is_correct']) && $answer['is_correct']) {
                $correct_answers++;
            }
            
            if (isset($answer['points'])) {
                $total_points += $answer['points'];
            }
            
            if (isset($answer['time_spent'])) {
                $total_time += $answer['time_spent'];
            }
        }
        
        $percentage = $total_questions > 0 ? round(($correct_answers / $total_questions) * 100, 1) : 0;
        $average_time = $total_questions > 0 ? round($total_time / $total_questions, 1) : 0;
        
        return array(
            'total_questions' => $total_questions,
            'correct_answers' => $correct_answers,
            'incorrect_answers' => $total_questions - $correct_answers,
            'total_points' => $total_points,
            'percentage' => $percentage,
            'total_time' => $total_time,
            'average_time' => $average_time,
            'grade' => $this->calculate_grade($percentage)
        );
    }
    
    /**
     * Calculate letter grade from percentage
     * 
     * @param float $percentage
     * @return string
     */
    private function calculate_grade($percentage) {
        if ($percentage >= 90) return 'A';
        if ($percentage >= 80) return 'B';
        if ($percentage >= 70) return 'C';
        if ($percentage >= 60) return 'D';
        return 'F';
    }
    
    /**
     * Get user's quiz history
     * 
     * @param int $user_id
     * @param int $limit
     * @return array
     */
    public function get_user_quiz_history($user_id, $limit = 10) {
        global $wpdb;
        
        $table_sessions = AVIDMOCK_SAT_TABLE_SESSIONS;
        $table_categories = AVIDMOCK_SAT_TABLE_CATEGORIES;
        
        $history = $wpdb->get_results($wpdb->prepare("
            SELECT 
                s.*,
                c.name as category_name
            FROM $table_sessions s
            LEFT JOIN $table_categories c ON s.category_id = c.id
            WHERE s.user_id = %d AND s.status = 'completed'
            ORDER BY s.end_time DESC
            LIMIT %d
        ", $user_id, $limit));
        
        // Format results
        $formatted_history = array();
        foreach ($history as $session) {
            $percentage = $session->total_questions > 0 ? 
                round(($session->correct_answers / $session->total_questions) * 100, 1) : 0;
            
            $formatted_history[] = array(
                'id' => $session->id,
                'category' => $session->category_name ?: __('All Categories', AVIDMOCK_SAT_TEXT_DOMAIN),
                'date' => $session->end_time,
                'total_questions' => $session->total_questions,
                'correct_answers' => $session->correct_answers,
                'percentage' => $percentage,
                'time_spent' => $session->time_spent,
                'points' => $session->total_points
            );
        }
        
        return $formatted_history;
    }
}