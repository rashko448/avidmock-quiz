<?php
/**
 * Public-facing functionality
 * 
 * @package AvidMock_SAT
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AvidMock_SAT_Public {
    
    private $plugin_name;
    private $version;
    
    public function __construct() {
        $this->plugin_name = 'avidmock-sat';
        $this->version = AVIDMOCK_SAT_VERSION;
        
        add_action('wp_enqueue_scripts', array($this, 'enqueue_styles'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('init', array($this, 'init_public'));
    }
    
    public function init_public() {
        // Initialize public functionality
        $this->setup_shortcodes();
    }
    
    public function enqueue_styles() {
        wp_enqueue_style(
            $this->plugin_name,
            AVIDMOCK_SAT_CSS_URL . 'public.css',
            array(),
            $this->version,
            'all'
        );
    }
    
    public function enqueue_scripts() {
        wp_enqueue_script(
            $this->plugin_name,
            AVIDMOCK_SAT_JS_URL . 'public.js',
            array('jquery'),
            $this->version,
            false
        );
        
        // Localize script for AJAX
        wp_localize_script($this->plugin_name, 'avidmockSAT', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('avidmock_sat_nonce'),
            'strings' => array(
                'loading' => __('Loading...', AVIDMOCK_SAT_TEXT_DOMAIN),
                'error' => __('An error occurred. Please try again.', AVIDMOCK_SAT_TEXT_DOMAIN),
                'select_answer' => __('Please select an answer', AVIDMOCK_SAT_TEXT_DOMAIN),
                'time_up' => __('Time is up!', AVIDMOCK_SAT_TEXT_DOMAIN),
                'quiz_complete' => __('Quiz Complete!', AVIDMOCK_SAT_TEXT_DOMAIN),
            )
        ));
    }
    
    private function setup_shortcodes() {
        // Register shortcodes for non-Elementor users
        add_shortcode('avidmock_quiz', array($this, 'quiz_shortcode'));
        add_shortcode('avidmock_quiz_stats', array($this, 'quiz_stats_shortcode'));
    }
    
    public function quiz_shortcode($atts) {
        $atts = shortcode_atts(array(
            'category' => '',
            'questions' => 10,
            'timer' => 90,
            'show_timer' => 'yes',
            'show_hint' => 'yes'
        ), $atts, 'avidmock_quiz');
        
        ob_start();
        
        // Simple quiz output for shortcode
        ?>
        <div class="avidmock-quiz-shortcode">
            <p><?php _e('AvidMock SAT Quiz', AVIDMOCK_SAT_TEXT_DOMAIN); ?></p>
            <p><?php _e('For best experience, use the Elementor widget.', AVIDMOCK_SAT_TEXT_DOMAIN); ?></p>
        </div>
        <?php
        
        return ob_get_clean();
    }
    
    public function quiz_stats_shortcode($atts) {
        $atts = shortcode_atts(array(
            'user_id' => get_current_user_id(),
            'category' => '',
            'show_chart' => 'yes'
        ), $atts, 'avidmock_quiz_stats');
        
        if (!$atts['user_id']) {
            return '<p>' . __('Please log in to view your quiz statistics.', AVIDMOCK_SAT_TEXT_DOMAIN) . '</p>';
        }
        
        ob_start();
        
        ?>
        <div class="avidmock-quiz-stats">
            <p><?php _e('Quiz statistics will be displayed here.', AVIDMOCK_SAT_TEXT_DOMAIN); ?></p>
        </div>
        <?php
        
        return ob_get_clean();
    }
}
