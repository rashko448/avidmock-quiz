<?php
/**
 * Database Manager Class
 * 
 * @package AvidMock_SAT
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AvidMock_SAT_Database_Manager {
    
    public function __construct() {
        add_action('init', array($this, 'check_database_version'));
    }
    
    public function check_database_version() {
        $installed_version = get_option('avidmock_sat_db_version', '0.0.0');
        
        if (version_compare($installed_version, AVIDMOCK_SAT_DB_VERSION, '<')) {
            $this->update_database($installed_version);
            update_option('avidmock_sat_db_version', AVIDMOCK_SAT_DB_VERSION);
        }
    }
    
    public function update_database($old_version) {
        // Handle database updates for future versions
        do_action('avidmock_sat_database_updated', $old_version, AVIDMOCK_SAT_DB_VERSION);
    }
    
    public function get_categories() {
        global $wpdb;
        $table = AVIDMOCK_SAT_TABLE_CATEGORIES;
        
        return $wpdb->get_results("SELECT * FROM $table WHERE is_active = 1 ORDER BY sort_order ASC, name ASC");
    }
    
    public function get_questions($category_id = null, $limit = null) {
        global $wpdb;
        $table = AVIDMOCK_SAT_TABLE_QUESTIONS;
        
        $where = "WHERE is_active = 1";
        $params = array();
        
        if ($category_id) {
            $where .= " AND category_id = %d";
            $params[] = $category_id;
        }
        
        $order = "ORDER BY RAND()";
        
        if ($limit) {
            $order .= " LIMIT %d";
            $params[] = $limit;
        }
        
        $sql = "SELECT * FROM $table $where $order";
        
        if (!empty($params)) {
            return $wpdb->get_results($wpdb->prepare($sql, ...$params));
        } else {
            return $wpdb->get_results($sql);
        }
    }
    
    public function get_question_options($question_id) {
        global $wpdb;
        $table = AVIDMOCK_SAT_TABLE_OPTIONS;
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE question_id = %d ORDER BY option_order ASC",
            $question_id
        ));
    }
    
    public function create_quiz_session($user_id, $category_id = null) {
        global $wpdb;
        $table = AVIDMOCK_SAT_TABLE_SESSIONS;
        
        $session_token = wp_generate_password(32, false);
        
        $data = array(
            'user_id' => $user_id,
            'category_id' => $category_id,
            'session_token' => $session_token,
            'user_ip' => $_SERVER['REMOTE_ADDR'] ?? '',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'status' => 'active'
        );
        
        $wpdb->insert($table, $data);
        
        return array(
            'session_id' => $wpdb->insert_id,
            'session_token' => $session_token
        );
    }
    
    public function get_quiz_session($session_token) {
        global $wpdb;
        $table = AVIDMOCK_SAT_TABLE_SESSIONS;
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE session_token = %s AND status = 'active'",
            $session_token
        ));
    }
    
    public function save_user_answer($session_id, $question_id, $answer_data) {
        global $wpdb;
        $table = AVIDMOCK_SAT_TABLE_ANSWERS;
        
        $data = array(
            'session_id' => $session_id,
            'question_id' => $question_id,
            'selected_option_id' => $answer_data['selected_option_id'] ?? null,
            'text_answer' => $answer_data['text_answer'] ?? null,
            'is_correct' => $answer_data['is_correct'] ?? false,
            'points_earned' => $answer_data['points_earned'] ?? 0,
            'time_spent' => $answer_data['time_spent'] ?? 0,
            'hint_used' => $answer_data['hint_used'] ?? false
        );
        
        return $wpdb->insert($table, $data);
    }
    
    public function complete_quiz_session($session_id) {
        global $wpdb;
        $table_sessions = AVIDMOCK_SAT_TABLE_SESSIONS;
        $table_answers = AVIDMOCK_SAT_TABLE_ANSWERS;
        
        // Get session answers summary
        $stats = $wpdb->get_row($wpdb->prepare("
            SELECT 
                COUNT(*) as total_questions,
                SUM(CASE WHEN is_correct = 1 THEN 1 ELSE 0 END) as correct_answers,
                SUM(points_earned) as total_points,
                SUM(time_spent) as time_spent
            FROM $table_answers 
            WHERE session_id = %d
        ", $session_id));
        
        // Update session
        $wpdb->update(
            $table_sessions,
            array(
                'status' => 'completed',
                'end_time' => current_time('mysql'),
                'total_questions' => $stats->total_questions,
                'correct_answers' => $stats->correct_answers,
                'total_points' => $stats->total_points,
                'time_spent' => $stats->time_spent
            ),
            array('id' => $session_id)
        );
        
        // Update user statistics
        $this->update_user_stats($session_id);
        
        return $stats;
    }
    
    private function update_user_stats($session_id) {
        global $wpdb;
        
        $session = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . AVIDMOCK_SAT_TABLE_SESSIONS . " WHERE id = %d",
            $session_id
        ));
        
        if (!$session || $session->user_id == 0) {
            return; // Skip for guest users
        }
        
        $table_stats = AVIDMOCK_SAT_TABLE_STATS;
        
        // Check if user stats exist
        $existing_stats = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_stats WHERE user_id = %d AND category_id = %d",
            $session->user_id,
            $session->category_id
        ));
        
        if ($existing_stats) {
            // Update existing stats
            $new_total_questions = $existing_stats->total_questions_attempted + $session->total_questions;
            $new_correct_answers = $existing_stats->total_correct_answers + $session->correct_answers;
            $new_total_time = $existing_stats->total_time_spent + $session->time_spent;
            $new_accuracy = ($new_total_questions > 0) ? ($new_correct_answers / $new_total_questions) * 100 : 0;
            $new_avg_time = ($new_total_questions > 0) ? $new_total_time / $new_total_questions : 0;
            
            $wpdb->update(
                $table_stats,
                array(
                    'total_questions_attempted' => $new_total_questions,
                    'total_correct_answers' => $new_correct_answers,
                    'total_time_spent' => $new_total_time,
                    'accuracy_percentage' => $new_accuracy,
                    'average_time_per_question' => $new_avg_time,
                    'last_quiz_date' => current_time('mysql'),
                    'best_score' => max($existing_stats->best_score, $session->total_points),
                    'total_sessions' => $existing_stats->total_sessions + 1
                ),
                array(
                    'user_id' => $session->user_id,
                    'category_id' => $session->category_id
                )
            );
        } else {
            // Create new stats
            $accuracy = ($session->total_questions > 0) ? ($session->correct_answers / $session->total_questions) * 100 : 0;
            $avg_time = ($session->total_questions > 0) ? $session->time_spent / $session->total_questions : 0;
            
            $wpdb->insert(
                $table_stats,
                array(
                    'user_id' => $session->user_id,
                    'category_id' => $session->category_id,
                    'total_questions_attempted' => $session->total_questions,
                    'total_correct_answers' => $session->correct_answers,
                    'total_time_spent' => $session->time_spent,
                    'accuracy_percentage' => $accuracy,
                    'average_time_per_question' => $avg_time,
                    'last_quiz_date' => current_time('mysql'),
                    'best_score' => $session->total_points,
                    'total_sessions' => 1
                )
            );
        }
    }
    
    public function get_user_stats($user_id, $category_id = null) {
        global $wpdb;
        $table = AVIDMOCK_SAT_TABLE_STATS;
        
        $where = "WHERE user_id = %d";
        $params = array($user_id);
        
        if ($category_id) {
            $where .= " AND category_id = %d";
            $params[] = $category_id;
        }
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table $where",
            ...$params
        ));
    }
}