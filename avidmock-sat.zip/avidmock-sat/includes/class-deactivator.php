<?php
/**
 * Plugin Deactivator Class
 * 
 * @package AvidMock_SAT
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AvidMock_SAT_Deactivator {
    
    public static function deactivate() {
        // Clear scheduled events
        wp_clear_scheduled_hook('avidmock_sat_cleanup_sessions');
        wp_clear_scheduled_hook('avidmock_sat_update_stats');
        
        // Clear transients
        self::clear_transients();
        
        // Clean up temporary data
        self::cleanup_temp_data();
        
        // Set deactivation timestamp
        update_option('avidmock_sat_deactivated_time', current_time('timestamp'));
        
        // Log deactivation
        do_action('avidmock_sat_deactivated');
    }
    
    private static function clear_transients() {
        global $wpdb;
        
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_avidmock_sat_%'");
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_avidmock_sat_%'");
    }
    
    private static function cleanup_temp_data() {
        global $wpdb;
        
        // Clean up expired sessions
        $table_sessions = $wpdb->prefix . 'avidmock_quiz_sessions';
        $wpdb->query("UPDATE $table_sessions SET status = 'expired' WHERE status = 'active' AND start_time < DATE_SUB(NOW(), INTERVAL 24 HOUR)");
        
        // Clear cache
        wp_cache_flush();
    }
}
