<?php
/**
 * Plugin Activator Class
 * 
 * @package AvidMock_SAT
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AvidMock_SAT_Activator {
    
    public static function activate() {
        self::create_database_tables();
        self::insert_default_data();
        self::set_default_options();
        self::create_upload_directories();
        
        update_option('avidmock_sat_activated_time', current_time('timestamp'));
        update_option('avidmock_sat_db_version', AVIDMOCK_SAT_VERSION);
    }
    
    private static function create_database_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Quiz Categories Table
        $table_categories = $wpdb->prefix . 'avidmock_quiz_categories';
        $sql_categories = "CREATE TABLE $table_categories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            description TEXT,
            slug VARCHAR(255) UNIQUE,
            icon VARCHAR(255),
            color VARCHAR(7) DEFAULT '#e4effb',
            is_active BOOLEAN DEFAULT TRUE,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) $charset_collate;";
        
        // Quiz Questions Table
        $table_questions = $wpdb->prefix . 'avidmock_quiz_questions';
        $sql_questions = "CREATE TABLE $table_questions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            category_id INT,
            question_text TEXT NOT NULL,
            question_type ENUM('multiple_choice', 'open_ended') DEFAULT 'multiple_choice',
            difficulty_level ENUM('easy', 'medium', 'hard') DEFAULT 'medium',
            explanation TEXT,
            hint TEXT,
            time_limit INT DEFAULT 90,
            points INT DEFAULT 1,
            is_active BOOLEAN DEFAULT TRUE,
            created_by INT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES $table_categories(id) ON DELETE SET NULL,
            INDEX idx_category (category_id),
            INDEX idx_difficulty (difficulty_level),
            INDEX idx_active (is_active)
        ) $charset_collate;";
        
        // Quiz Answer Options Table
        $table_options = $wpdb->prefix . 'avidmock_quiz_answer_options';
        $sql_options = "CREATE TABLE $table_options (
            id INT AUTO_INCREMENT PRIMARY KEY,
            question_id INT NOT NULL,
            option_text TEXT NOT NULL,
            is_correct BOOLEAN DEFAULT FALSE,
            option_order INT DEFAULT 0,
            explanation TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (question_id) REFERENCES $table_questions(id) ON DELETE CASCADE,
            INDEX idx_question (question_id),
            INDEX idx_correct (is_correct)
        ) $charset_collate;";
        
        // Quiz Sessions Table
        $table_sessions = $wpdb->prefix . 'avidmock_quiz_sessions';
        $sql_sessions = "CREATE TABLE $table_sessions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT DEFAULT 0,
            category_id INT,
            session_token VARCHAR(255) UNIQUE,
            start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            end_time TIMESTAMP NULL,
            total_questions INT DEFAULT 0,
            correct_answers INT DEFAULT 0,
            total_points INT DEFAULT 0,
            time_spent INT DEFAULT 0,
            status ENUM('active', 'completed', 'paused', 'expired') DEFAULT 'active',
            user_ip VARCHAR(45),
            user_agent TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES $table_categories(id) ON DELETE SET NULL,
            INDEX idx_user (user_id),
            INDEX idx_status (status),
            INDEX idx_session_token (session_token)
        ) $charset_collate;";
        
        // Quiz User Answers Table
        $table_answers = $wpdb->prefix . 'avidmock_quiz_user_answers';
        $sql_answers = "CREATE TABLE $table_answers (
            id INT AUTO_INCREMENT PRIMARY KEY,
            session_id INT NOT NULL,
            question_id INT NOT NULL,
            selected_option_id INT NULL,
            text_answer TEXT NULL,
            is_correct BOOLEAN,
            points_earned INT DEFAULT 0,
            time_spent INT,
            hint_used BOOLEAN DEFAULT FALSE,
            attempt_number INT DEFAULT 1,
            answered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (session_id) REFERENCES $table_sessions(id) ON DELETE CASCADE,
            FOREIGN KEY (question_id) REFERENCES $table_questions(id) ON DELETE CASCADE,
            FOREIGN KEY (selected_option_id) REFERENCES $table_options(id) ON DELETE SET NULL,
            INDEX idx_session (session_id),
            INDEX idx_question (question_id),
            INDEX idx_correct (is_correct)
        ) $charset_collate;";
        
        // Quiz User Statistics Table
        $table_stats = $wpdb->prefix . 'avidmock_quiz_user_stats';
        $sql_stats = "CREATE TABLE $table_stats (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            category_id INT,
            total_questions_attempted INT DEFAULT 0,
            total_correct_answers INT DEFAULT 0,
            total_points_earned INT DEFAULT 0,
            total_time_spent INT DEFAULT 0,
            average_time_per_question DECIMAL(5,2) DEFAULT 0,
            accuracy_percentage DECIMAL(5,2) DEFAULT 0,
            last_quiz_date TIMESTAMP NULL,
            best_score INT DEFAULT 0,
            streak_count INT DEFAULT 0,
            total_sessions INT DEFAULT 0,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY unique_user_category (user_id, category_id),
            FOREIGN KEY (category_id) REFERENCES $table_categories(id) ON DELETE SET NULL,
            INDEX idx_user (user_id),
            INDEX idx_accuracy (accuracy_percentage)
        ) $charset_collate;";
        
        // Quiz Settings Table
        $table_settings = $wpdb->prefix . 'avidmock_quiz_settings';
        $sql_settings = "CREATE TABLE $table_settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            setting_key VARCHAR(255) UNIQUE NOT NULL,
            setting_value LONGTEXT,
            setting_type ENUM('string', 'number', 'boolean', 'array', 'object') DEFAULT 'string',
            description TEXT,
            is_autoload BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_key (setting_key),
            INDEX idx_autoload (is_autoload)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        dbDelta($sql_categories);
        dbDelta($sql_questions);
        dbDelta($sql_options);
        dbDelta($sql_sessions);
        dbDelta($sql_answers);
        dbDelta($sql_stats);
        dbDelta($sql_settings);
        
        update_option('avidmock_sat_db_version', AVIDMOCK_SAT_DB_VERSION);
    }
    
    private static function insert_default_data() {
        global $wpdb;
        
        $table_categories = $wpdb->prefix . 'avidmock_quiz_categories';
        $table_questions = $wpdb->prefix . 'avidmock_quiz_questions';
        $table_options = $wpdb->prefix . 'avidmock_quiz_answer_options';
        
        // Check if categories already exist
        $existing_categories = $wpdb->get_var("SELECT COUNT(*) FROM $table_categories");
        
        if ($existing_categories == 0) {
            // Insert default categories
            $categories = [
                [
                    'name' => 'SAT Mathematics',
                    'description' => 'SAT Math practice questions including Algebra, Geometry, and Advanced Math',
                    'slug' => 'sat-mathematics',
                    'icon' => 'fa-calculator',
                    'color' => '#e4effb'
                ],
                [
                    'name' => 'Algebra',
                    'description' => 'Linear equations, quadratic functions, and algebraic expressions',
                    'slug' => 'algebra',
                    'icon' => 'fa-square-root-alt',
                    'color' => '#def7ea'
                ],
                [
                    'name' => 'Geometry',
                    'description' => 'Geometric shapes, areas, volumes, and coordinate geometry',
                    'slug' => 'geometry',
                    'icon' => 'fa-shapes',
                    'color' => '#eae8f8'
                ]
            ];
            
            foreach ($categories as $category) {
                $wpdb->insert($table_categories, $category);
            }
            
            // Insert sample questions
            self::insert_sample_questions();
        }
    }
    
    private static function insert_sample_questions() {
        global $wpdb;
        
        $table_questions = $wpdb->prefix . 'avidmock_quiz_questions';
        $table_options = $wpdb->prefix . 'avidmock_quiz_answer_options';
        
        // Sample SAT Math question
        $question1 = [
            'category_id' => 1,
            'question_text' => 'For what value of p does the equation -3px + 26 = 11(x + 3) + 7(x - 1) have infinitely many solutions?',
            'question_type' => 'multiple_choice',
            'difficulty_level' => 'medium',
            'explanation' => 'A linear equation has infinitely many solutions when the coefficients of x are equal and the constant terms are equal on both sides.',
            'hint' => 'Distribute the terms on the right side and compare coefficients.',
            'time_limit' => 90,
            'points' => 1
        ];
        
        $wpdb->insert($table_questions, $question1);
        $question_id = $wpdb->insert_id;
        
        // Insert answer options
        $options1 = [
            ['question_id' => $question_id, 'option_text' => '-6', 'is_correct' => true, 'option_order' => 1],
            ['question_id' => $question_id, 'option_text' => '-3', 'is_correct' => false, 'option_order' => 2],
            ['question_id' => $question_id, 'option_text' => '3', 'is_correct' => false, 'option_order' => 3],
            ['question_id' => $question_id, 'option_text' => '18', 'is_correct' => false, 'option_order' => 4]
        ];
        
        foreach ($options1 as $option) {
            $wpdb->insert($table_options, $option);
        }
        
        // Sample Algebra question
        $question2 = [
            'category_id' => 2,
            'question_text' => 'If 2x + 5 = 13, what is the value of x?',
            'question_type' => 'multiple_choice',
            'difficulty_level' => 'easy',
            'explanation' => 'Solve by isolating x: 2x + 5 = 13, so 2x = 8, therefore x = 4.',
            'hint' => 'Subtract 5 from both sides, then divide by 2.',
            'time_limit' => 60,
            'points' => 1
        ];
        
        $wpdb->insert($table_questions, $question2);
        $question_id = $wpdb->insert_id;
        
        $options2 = [
            ['question_id' => $question_id, 'option_text' => '4', 'is_correct' => true, 'option_order' => 1],
            ['question_id' => $question_id, 'option_text' => '6', 'is_correct' => false, 'option_order' => 2],
            ['question_id' => $question_id, 'option_text' => '8', 'is_correct' => false, 'option_order' => 3],
            ['question_id' => $question_id, 'option_text' => '9', 'is_correct' => false, 'option_order' => 4]
        ];
        
        foreach ($options2 as $option) {
            $wpdb->insert($table_options, $option);
        }
    }
    
    private static function set_default_options() {
        $default_options = [
            'default_time_limit' => 90,
            'enable_hints' => true,
            'enable_explanations' => true,
            'require_login' => false,
            'save_guest_results' => true,
            'primary_color' => '#e4effb',
            'correct_color' => '#def7ea',
            'incorrect_color' => '#f8d7da',
            'accent_color' => '#eae8f8'
        ];
        
        foreach ($default_options as $key => $value) {
            avidmock_sat_update_option($key, $value);
        }
    }
    
    private static function create_upload_directories() {
        $upload_dir = wp_upload_dir();
        $avidmock_upload_dir = $upload_dir['basedir'] . '/avidmock-sat';
        
        if (!file_exists($avidmock_upload_dir)) {
            wp_mkdir_p($avidmock_upload_dir);
            wp_mkdir_p($avidmock_upload_dir . '/exports');
            wp_mkdir_p($avidmock_upload_dir . '/imports');
            
            // Create .htaccess for security
            $htaccess_content = "Options -Indexes\n";
            $htaccess_content .= "<Files *.php>\n";
            $htaccess_content .= "Deny from all\n";
            $htaccess_content .= "</Files>\n";
            
            file_put_contents($avidmock_upload_dir . '/.htaccess', $htaccess_content);
        }
    }
}
