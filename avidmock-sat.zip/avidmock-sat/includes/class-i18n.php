<?php
/**
 * Internationalization Class
 * 
 * @package AvidMock_SAT
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AvidMock_SAT_i18n {
    
    public function load_plugin_textdomain() {
        load_plugin_textdomain(
            AVIDMOCK_SAT_TEXT_DOMAIN,
            false,
            dirname(dirname(plugin_basename(__FILE__))) . '/languages/'
        );
    }
}