<?php
/**
 * Plugin Loader Class
 * 
 * Manages all hooks for the plugin
 * 
 * @package AvidMock_SAT
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * AvidMock SAT Loader Class
 * 
 * Maintains a list of all hooks that are registered throughout
 * the plugin, and registers them with the WordPress API. Call the
 * run function to execute the list of actions and filters.
 */
class AvidMock_SAT_Loader {
    
    /**
     * The array of actions registered with WordPress.
     * 
     * @since 1.0.0
     * @var array $actions
     */
    protected $actions;
    
    /**
     * The array of filters registered with WordPress.
     * 
     * @since 1.0.0
     * @var array $filters
     */
    protected $filters;
    
    /**
     * Initialize the collections used to maintain the actions and filters.
     * 
     * @since 1.0.0
     */
    public function __construct() {
        $this->actions = array();
        $this->filters = array();
    }
    
    /**
     * Add a new action to the collection to be registered with WordPress.
     * 
     * @since 1.0.0
     * @param string $hook The name of the WordPress action that is being registered.
     * @param object $component A reference to the instance of the object on which the action is defined.
     * @param string $callback The name of the function definition on the $component.
     * @param int $priority Optional. The priority at which the function should be fired. Default is 10.
     * @param int $accepted_args Optional. The number of arguments that should be passed to the $callback. Default is 1.
     */
    public function add_action($hook, $component, $callback, $priority = 10, $accepted_args = 1) {
        $this->actions = $this->add($this->actions, $hook, $component, $callback, $priority, $accepted_args);
    }
    
    /**
     * Add a new filter to the collection to be registered with WordPress.
     * 
     * @since 1.0.0
     * @param string $hook The name of the WordPress filter that is being registered.
     * @param object $component A reference to the instance of the object on which the filter is defined.
     * @param string $callback The name of the function definition on the $component.
     * @param int $priority Optional. The priority at which the function should be fired. Default is 10.
     * @param int $accepted_args Optional. The number of arguments that should be passed to the $callback. Default is 1.
     */
    public function add_filter($hook, $component, $callback, $priority = 10, $accepted_args = 1) {
        $this->filters = $this->add($this->filters, $hook, $component, $callback, $priority, $accepted_args);
    }
    
    /**
     * A utility function that is used to register the actions and hooks into a single
     * collection.
     * 
     * @since 1.0.0
     * @param array $hooks The collection of hooks that is being registered (that is, actions or filters).
     * @param string $hook The name of the WordPress filter that is being registered.
     * @param object $component A reference to the instance of the object on which the filter is defined.
     * @param string $callback The name of the function definition on the $component.
     * @param int $priority The priority at which the function should be fired.
     * @param int $accepted_args The number of arguments that should be passed to the $callback.
     * @return array The collection of actions and filters registered with WordPress.
     */
    private function add($hooks, $hook, $component, $callback, $priority, $accepted_args) {
        $hooks[] = array(
            'hook'          => $hook,
            'component'     => $component,
            'callback'      => $callback,
            'priority'      => $priority,
            'accepted_args' => $accepted_args
        );
        
        return $hooks;
    }
    
    /**
     * Register the filters and actions with WordPress.
     * 
     * @since 1.0.0
     */
    public function run() {
        foreach ($this->filters as $hook) {
            add_filter(
                $hook['hook'],
                array($hook['component'], $hook['callback']),
                $hook['priority'],
                $hook['accepted_args']
            );
        }
        
        foreach ($this->actions as $hook) {
            add_action(
                $hook['hook'],
                array($hook['component'], $hook['callback']),
                $hook['priority'],
                $hook['accepted_args']
            );
        }
    }
    
    /**
     * Get all registered actions.
     * 
     * @since 1.0.0
     * @return array
     */
    public function get_actions() {
        return $this->actions;
    }
    
    /**
     * Get all registered filters.
     * 
     * @since 1.0.0
     * @return array
     */
    public function get_filters() {
        return $this->filters;
    }
    
    /**
     * Remove a specific action.
     * 
     * @since 1.0.0
     * @param string $hook
     * @param string $callback
     */
    public function remove_action($hook, $callback) {
        foreach ($this->actions as $key => $action) {
            if ($action['hook'] === $hook && $action['callback'] === $callback) {
                unset($this->actions[$key]);
                break;
            }
        }
    }
    
    /**
     * Remove a specific filter.
     * 
     * @since 1.0.0
     * @param string $hook
     * @param string $callback
     */
    public function remove_filter($hook, $callback) {
        foreach ($this->filters as $key => $filter) {
            if ($filter['hook'] === $hook && $filter['callback'] === $callback) {
                unset($this->filters[$key]);
                break;
            }
        }
    }
    
    /**
     * Check if a specific action is registered.
     * 
     * @since 1.0.0
     * @param string $hook
     * @param string $callback
     * @return bool
     */
    public function has_action($hook, $callback = null) {
        foreach ($this->actions as $action) {
            if ($action['hook'] === $hook) {
                if ($callback === null || $action['callback'] === $callback) {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Check if a specific filter is registered.
     * 
     * @since 1.0.0
     * @param string $hook
     * @param string $callback
     * @return bool
     */
    public function has_filter($hook, $callback = null) {
        foreach ($this->filters as $filter) {
            if ($filter['hook'] === $hook) {
                if ($callback === null || $filter['callback'] === $callback) {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Get hook count.
     * 
     * @since 1.0.0
     * @return array
     */
    public function get_hook_count() {
        return array(
            'actions' => count($this->actions),
            'filters' => count($this->filters),
            'total' => count($this->actions) + count($this->filters)
        );
    }
}