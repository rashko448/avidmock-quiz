<?php
/**
 * Quiz AJAX Handler
 * 
 * @package AvidMock_SAT
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AvidMock_SAT_Quiz_Ajax {
    
    private $db_manager;
    
    public function __construct() {
        $this->db_manager = new AvidMock_SAT_Database_Manager();
        
        // Register AJAX actions
        add_action('wp_ajax_avidmock_start_quiz', array($this, 'start_quiz'));
        add_action('wp_ajax_nopriv_avidmock_start_quiz', array($this, 'start_quiz'));
        
        add_action('wp_ajax_avidmock_get_question', array($this, 'get_question'));
        add_action('wp_ajax_nopriv_avidmock_get_question', array($this, 'get_question'));
        
        add_action('wp_ajax_avidmock_submit_answer', array($this, 'submit_answer'));
        add_action('wp_ajax_nopriv_avidmock_submit_answer', array($this, 'submit_answer'));
        
        add_action('wp_ajax_avidmock_get_hint', array($this, 'get_hint'));
        add_action('wp_ajax_nopriv_avidmock_get_hint', array($this, 'get_hint'));
        
        add_action('wp_ajax_avidmock_end_quiz', array($this, 'end_quiz'));
        add_action('wp_ajax_nopriv_avidmock_end_quiz', array($this, 'end_quiz'));
    }
    
    public function start_quiz() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'avidmock_sat_nonce')) {
            wp_die('Security check failed');
        }
        
        $category_id = isset($_POST['category_id']) ? intval($_POST['category_id']) : null;
        $question_count = isset($_POST['question_count']) ? intval($_POST['question_count']) : 10;
        $user_id = get_current_user_id();
        
        try {
            // Create quiz session
            $session = $this->db_manager->create_quiz_session($user_id, $category_id);
            
            // Get questions
            $questions = $this->db_manager->get_questions($category_id, $question_count);
            
            if (empty($questions)) {
                wp_send_json_error(array(
                    'message' => __('No questions found for this category.', AVIDMOCK_SAT_TEXT_DOMAIN)
                ));
            }
            
            // Store questions in session
            set_transient('avidmock_quiz_questions_' . $session['session_token'], $questions, 3600);
            
            wp_send_json_success(array(
                'session_id' => $session['session_id'],
                'session_token' => $session['session_token'],
                'total_questions' => count($questions),
                'message' => __('Quiz started successfully!', AVIDMOCK_SAT_TEXT_DOMAIN)
            ));
            
        } catch (Exception $e) {
            wp_send_json_error(array(
                'message' => __('Failed to start quiz. Please try again.', AVIDMOCK_SAT_TEXT_DOMAIN)
            ));
        }
    }
    
    public function get_question() {
        if (!wp_verify_nonce($_POST['nonce'], 'avidmock_sat_nonce')) {
            wp_die('Security check failed');
        }
        
        $session_token = sanitize_text_field($_POST['session_token']);
        $question_index = intval($_POST['question_index']);
        
        // Get session
        $session = $this->db_manager->get_quiz_session($session_token);
        if (!$session) {
            wp_send_json_error(array(
                'message' => __('Invalid session.', AVIDMOCK_SAT_TEXT_DOMAIN)
            ));
        }
        
        // Get questions from transient
        $questions = get_transient('avidmock_quiz_questions_' . $session_token);
        if (!$questions || !isset($questions[$question_index])) {
            wp_send_json_error(array(
                'message' => __('Question not found.', AVIDMOCK_SAT_TEXT_DOMAIN)
            ));
        }
        
        $question = $questions[$question_index];
        
        // Get answer options
        $options = $this->db_manager->get_question_options($question->id);
        
        // Prepare response data
        $question_data = array(
            'id' => $question->id,
            'text' => $question->question_text,
            'type' => $question->question_type,
            'hint' => $question->hint,
            'time_limit' => $question->time_limit,
            'options' => array()
        );
        
        foreach ($options as $option) {
            $question_data['options'][] = array(
                'id' => $option->id,
                'text' => $option->option_text,
                'order' => $option->option_order
            );
        }
        
        wp_send_json_success($question_data);
    }
    
    public function submit_answer() {
        if (!wp_verify_nonce($_POST['nonce'], 'avidmock_sat_nonce')) {
            wp_die('Security check failed');
        }
        
        $session_token = sanitize_text_field($_POST['session_token']);
        $question_id = intval($_POST['question_id']);
        $selected_option_id = isset($_POST['selected_option_id']) ? intval($_POST['selected_option_id']) : null;
        $text_answer = isset($_POST['text_answer']) ? sanitize_textarea_field($_POST['text_answer']) : null;
        $time_spent = intval($_POST['time_spent']);
        $hint_used = isset($_POST['hint_used']) ? (bool)$_POST['hint_used'] : false;
        
        // Get session
        $session = $this->db_manager->get_quiz_session($session_token);
        if (!$session) {
            wp_send_json_error(array(
                'message' => __('Invalid session.', AVIDMOCK_SAT_TEXT_DOMAIN)
            ));
        }
        
        try {
            // Get question details
            global $wpdb;
            $question = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM " . AVIDMOCK_SAT_TABLE_QUESTIONS . " WHERE id = %d",
                $question_id
            ));
            
            if (!$question) {
                wp_send_json_error(array(
                    'message' => __('Question not found.', AVIDMOCK_SAT_TEXT_DOMAIN)
                ));
            }
            
            $is_correct = false;
            $points_earned = 0;
            $correct_option_id = null;
            
            if ($question->question_type === 'multiple_choice' && $selected_option_id) {
                // Check if selected option is correct
                $selected_option = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM " . AVIDMOCK_SAT_TABLE_OPTIONS . " WHERE id = %d",
                    $selected_option_id
                ));
                
                $is_correct = $selected_option && $selected_option->is_correct;
                
                // Get correct option for response
                $correct_option = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM " . AVIDMOCK_SAT_TABLE_OPTIONS . " WHERE question_id = %d AND is_correct = 1",
                    $question_id
                ));
                
                $correct_option_id = $correct_option ? $correct_option->id : null;
            }
            
            if ($is_correct) {
                $points_earned = $question->points;
            }
            
            // Save user answer
            $answer_data = array(
                'selected_option_id' => $selected_option_id,
                'text_answer' => $text_answer,
                'is_correct' => $is_correct,
                'points_earned' => $points_earned,
                'time_spent' => $time_spent,
                'hint_used' => $hint_used
            );
            
            $this->db_manager->save_user_answer($session->id, $question_id, $answer_data);
            
            // Prepare response
            $response = array(
                'is_correct' => $is_correct,
                'points_earned' => $points_earned,
                'correct_option_id' => $correct_option_id,
                'explanation' => $question->explanation
            );
            
            wp_send_json_success($response);
            
        } catch (Exception $e) {
            wp_send_json_error(array(
                'message' => __('Failed to submit answer. Please try again.', AVIDMOCK_SAT_TEXT_DOMAIN)
            ));
        }
    }
    
    public function get_hint() {
        if (!wp_verify_nonce($_POST['nonce'], 'avidmock_sat_nonce')) {
            wp_die('Security check failed');
        }
        
        $question_id = intval($_POST['question_id']);
        
        global $wpdb;
        $question = $wpdb->get_row($wpdb->prepare(
            "SELECT hint FROM " . AVIDMOCK_SAT_TABLE_QUESTIONS . " WHERE id = %d",
            $question_id
        ));
        
        if (!$question || empty($question->hint)) {
            wp_send_json_error(array(
                'message' => __('No hint available for this question.', AVIDMOCK_SAT_TEXT_DOMAIN)
            ));
        }
        
        wp_send_json_success(array(
            'hint' => $question->hint
        ));
    }
    
    public function end_quiz() {
        if (!wp_verify_nonce($_POST['nonce'], 'avidmock_sat_nonce')) {
            wp_die('Security check failed');
        }
        
        $session_token = sanitize_text_field($_POST['session_token']);
        
        // Get session
        $session = $this->db_manager->get_quiz_session($session_token);
        if (!$session) {
            wp_send_json_error(array(
                'message' => __('Invalid session.', AVIDMOCK_SAT_TEXT_DOMAIN)
            ));
        }
        
        try {
            // Complete the quiz session
            $final_stats = $this->db_manager->complete_quiz_session($session->id);
            
            // Clean up transients
            delete_transient('avidmock_quiz_questions_' . $session_token);
            
            // Calculate final score percentage
            $score_percentage = 0;
            if ($final_stats->total_questions > 0) {
                $score_percentage = round(($final_stats->correct_answers / $final_stats->total_questions) * 100, 1);
            }
            
            // Format time spent
            $time_formatted = $this->format_time($final_stats->time_spent);
            
            wp_send_json_success(array(
                'total_questions' => $final_stats->total_questions,
                'correct_answers' => $final_stats->correct_answers,
                'total_points' => $final_stats->total_points,
                'time_spent' => $final_stats->time_spent,
                'time_formatted' => $time_formatted,
                'score_percentage' => $score_percentage,
                'message' => __('Quiz completed successfully!', AVIDMOCK_SAT_TEXT_DOMAIN)
            ));
            
        } catch (Exception $e) {
            wp_send_json_error(array(
                'message' => __('Failed to end quiz. Please try again.', AVIDMOCK_SAT_TEXT_DOMAIN)
            ));
        }
    }
    
    /**
     * Format time in seconds to readable format
     * 
     * @param int $seconds
     * @return string
     */
    private function format_time($seconds) {
        $minutes = floor($seconds / 60);
        $seconds = $seconds % 60;
        
        return sprintf('%02d:%02d', $minutes, $seconds);
    }
}